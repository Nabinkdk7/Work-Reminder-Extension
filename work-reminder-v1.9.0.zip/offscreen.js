/* Offscreen document: owns everything that needs a DOM —
   - alarm/reminder sounds (WebAudio, generated, no asset files)
   - Text-to-speech through the Web Speech API (fallback voice engine)
   It replies to messages addressed to {target:"offscreen"} from the worker. */
(function () {
  "use strict";

  let audioCtx = null;
  let masterBus = null;
  let activeSound = null; // gain group for the currently playing alert

  function ctx() {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { audioCtx = null; }
    }
    if (audioCtx && audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
    return audioCtx;
  }

  /* Master chain: a safety limiter that only catches peaks, so sounds stay
     clean and loud without the squashed, quiet feel of a heavy compressor. */
  function bus() {
    const c = ctx(); if (!c) return null;
    if (!masterBus) {
      masterBus = c.createGain();
      masterBus.gain.value = 1;
      const comp = c.createDynamicsCompressor();
      comp.threshold.value = -2;
      comp.knee.value = 4;
      comp.ratio.value = 12;
      comp.attack.value = 0.002;
      comp.release.value = 0.22;
      masterBus.connect(comp).connect(c.destination);
    }
    return masterBus;
  }

  /* Fade and disconnect the current alert. Used by Do Not Disturb, by the
     "stop" action and before starting a new preview so sounds never stack. */
  function stopSound() {
    const group = activeSound;
    activeSound = null;
    if (!group) return;
    try {
      const c = ctx();
      if (c) {
        const t = c.currentTime;
        const level = Math.max(0.0001, +group.gain.value || 0.0001);
        group.gain.cancelScheduledValues(t);
        group.gain.setValueAtTime(level, t);
        group.gain.exponentialRampToValueAtTime(0.0001, t + 0.025);
      }
    } catch (e) {}
    setTimeout(() => { try { group.disconnect(); } catch (e) {} }, 80);
  }

  /* Warm, clean overtone recipe used when a note doesn't specify its own. */
  const HARMONIC = [[1, 1], [2, 0.16], [3, 0.06]];

  /* One expressive voice: smooth attack/decay envelope, a lowpass to tame
     harshness, stereo placement for width, and additive partials for body.
     opts: freq, start, dur, type, vol, attack, release, filter, pan,
           partials ([[mult, amp], ...]), detune, glide. */
  function note(o) {
    const c = ctx(); const out = bus();
    if (!c || !out) return;
    const t0 = c.currentTime + (o.start || 0);
    const dur = Math.max(0.05, o.dur == null ? 0.2 : o.dur);
    const vol = Math.max(0.0002, o.vol == null ? 0.5 : o.vol);
    const atk = o.attack == null ? 0.012 : o.attack;
    const rel = o.release == null ? dur : o.release;
    const type = o.type || "sine";

    const env = c.createGain();
    env.gain.setValueAtTime(0.0002, t0);
    env.gain.linearRampToValueAtTime(vol, t0 + atk);
    env.gain.exponentialRampToValueAtTime(0.0004, t0 + atk + rel);

    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(o.filter || 6800, t0);
    lp.Q.value = 0.0006;

    const pan = c.createStereoPanner();
    pan.pan.value = Math.max(-1, Math.min(1, o.pan || 0));

    env.connect(lp); lp.connect(pan); pan.connect(activeSound || out);

    const partials = o.partials || HARMONIC;
    partials.forEach((p, i) => {
      const mult = p[0], amp = p[1];
      const osc = c.createOscillator();
      osc.type = type;
      const f = (o.freq || 440) * mult;
      osc.frequency.setValueAtTime(Math.max(1, f), t0);
      if (o.glide) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.glide * mult), t0 + atk + rel);
      if (o.detune) osc.detune.setValueAtTime(o.detune * (i % 2 ? 1 : -1), t0);
      const g = c.createGain();
      g.gain.value = amp;
      osc.connect(g); g.connect(env);
      osc.start(t0);
      osc.stop(t0 + atk + rel + 0.08);
    });
  }

  function playSound(name, volume) {
    if (!name || name === "none") return;
    const n = Number(volume);
    const v = isFinite(n) ? Math.min(1, Math.max(0, n / 100)) : 0.8;
    if (v <= 0) return;
    const c = ctx();
    const out = bus();
    if (!c || !out) return;
    stopSound();
    const group = c.createGain();
    group.gain.value = 1;
    group.connect(out);
    activeSound = group;
    // Let the group go after the longest pattern finishes, even if the popup
    // is gone. The identity check keeps a newer preview safe.
    setTimeout(() => {
      if (activeSound !== group) return;
      activeSound = null;
      try { group.disconnect(); } catch (e) {}
    }, 5000);
    const d = 0.18; // short, punchy note length
    switch (name) {
      case "soft":
        note({ freq: 659.25, start: 0, dur: d * 2.4, type: "sine", vol: v * 0.42, attack: 0.03, pan: -0.12 });
        note({ freq: 987.77, start: d * 1.3, dur: d * 2.6, type: "sine", vol: v * 0.36, attack: 0.03, pan: 0.12 });
        break;
      case "bell":
        note({ freq: 1318.5, start: 0, dur: d * 3, type: "sine", vol: v * 0.5, filter: 9000, release: d * 3, partials: [[1, 1], [2.76, 0.35], [5.4, 0.14]] });
        note({ freq: 1760, start: d * 0.8, dur: d * 3, type: "sine", vol: v * 0.3, filter: 9000, release: d * 3, partials: [[1, 1], [2.76, 0.3]] });
        break;
      case "glass":
        note({ freq: 1567.98, start: 0, dur: d * 3.4, type: "sine", vol: v * 0.42, filter: 11000, release: d * 3.4, partials: [[1, 1], [2, 0.22], [3, 0.08]] });
        note({ freq: 2093, start: d * 0.7, dur: d * 3.4, type: "sine", vol: v * 0.3, filter: 12000, release: d * 3.2, partials: [[1, 1], [2, 0.18]] });
        break;
      case "gentle":
        note({ freq: 392, start: 0, dur: d * 3.2, type: "sine", vol: v * 0.4, attack: 0.06, pan: -0.1 });
        note({ freq: 523.25, start: d * 1.3, dur: d * 3.4, type: "sine", vol: v * 0.4, attack: 0.06, pan: 0.1 });
        break;
      case "digital":
        note({ freq: 880, start: 0, dur: d, type: "triangle", vol: v * 0.42, filter: 5200, partials: [[1, 1], [3, 0.12]] });
        note({ freq: 1174.66, start: d * 0.75, dur: d, type: "triangle", vol: v * 0.42, filter: 5200, partials: [[1, 1], [3, 0.12]] });
        note({ freq: 1567.98, start: d * 1.5, dur: d * 1.4, type: "triangle", vol: v * 0.4, filter: 5600, partials: [[1, 1], [2, 0.14]] });
        break;
      case "cascade":
        note({ freq: 1318.5, start: 0, dur: d * 1.3, type: "sine", vol: v * 0.42, pan: 0.18 });
        note({ freq: 1046.5, start: d * 0.7, dur: d * 1.3, type: "sine", vol: v * 0.4, pan: 0 });
        note({ freq: 783.99, start: d * 1.4, dur: d * 1.8, type: "sine", vol: v * 0.4, pan: -0.18 });
        break;
      case "sunrise":
        // warm slow sunrise — a soft major chord blooming upward
        note({ freq: 261.63, start: 0, dur: d * 3.6, type: "sine", vol: v * 0.36, attack: 0.12, pan: -0.16, partials: [[1, 1], [2, 0.14], [3, 0.05]] });
        note({ freq: 329.63, start: d * 1.0, dur: d * 3.6, type: "sine", vol: v * 0.36, attack: 0.12, pan: 0 });
        note({ freq: 392.0, start: d * 2.0, dur: d * 3.8, type: "sine", vol: v * 0.4, attack: 0.14, pan: 0.16 });
        note({ freq: 523.25, start: d * 3.0, dur: d * 4, type: "sine", vol: v * 0.3, attack: 0.16, pan: 0.1 });
        break;
      case "melody":
        // tiny music-box phrase — cheerful and polished
        note({ freq: 659.25, start: 0, dur: d * 1.5, type: "triangle", vol: v * 0.4, filter: 6000, pan: -0.08, partials: [[1, 1], [4, 0.14]] });
        note({ freq: 783.99, start: d * 0.85, dur: d * 1.5, type: "triangle", vol: v * 0.4, filter: 6200, pan: -0.04, partials: [[1, 1], [4, 0.14]] });
        note({ freq: 1046.5, start: d * 1.7, dur: d * 2.6, type: "triangle", vol: v * 0.38, filter: 6400, pan: 0.08, partials: [[1, 1], [3, 0.12]] });
        note({ freq: 783.99, start: d * 3.0, dur: d * 2.2, type: "triangle", vol: v * 0.32, filter: 6000, pan: 0.12, partials: [[1, 1], [3, 0.12]] });
        break;
      case "pop":
        // bright friendly double-pop with a soft pitch drop
        note({ freq: 660, start: 0, dur: d * 0.9, type: "sine", vol: v * 0.5, filter: 5600, attack: 0.006, glide: 520, partials: [[1, 1]] });
        note({ freq: 990, start: d * 0.7, dur: d * 1.1, type: "sine", vol: v * 0.45, filter: 6000, partials: [[1, 1], [2, 0.18]] });
        break;
      case "zen":
        // calm singing-bowl hum — low, airy and soothing
        note({ freq: 220.0, start: 0, dur: d * 4.6, type: "sine", vol: v * 0.42, attack: 0.18, release: d * 4.6, detune: 4, pan: -0.1, partials: [[1, 1], [2.76, 0.22], [4.1, 0.1]] });
        note({ freq: 330.0, start: d * 0.6, dur: d * 4.4, type: "sine", vol: v * 0.26, attack: 0.2, release: d * 4.4, pan: 0.12 });
        break;
      case "sparkle":
        // quick pentatonic shimmer — light and engaging
        note({ freq: 1046.5, start: 0, dur: d * 0.9, type: "sine", vol: v * 0.34, filter: 11000, pan: -0.2 });
        note({ freq: 1174.66, start: d * 0.45, dur: d * 0.9, type: "sine", vol: v * 0.34, filter: 11000, pan: -0.06 });
        note({ freq: 1318.5, start: d * 0.9, dur: d * 0.9, type: "sine", vol: v * 0.34, filter: 12000, pan: 0.06 });
        note({ freq: 1567.98, start: d * 1.35, dur: d * 1.7, type: "sine", vol: v * 0.32, filter: 13000, pan: 0.2 });
        break;
      case "alarm":
        // firm but smoother than the old square buzz
        for (let i = 0; i < 4; i++) {
          note({ freq: i % 2 ? 740 : 988, start: i * d * 0.85, dur: d * 0.7, type: "triangle", vol: v * 0.4, filter: 4200, attack: 0.006, partials: [[1, 1], [2, 0.4]] });
        }
        break;
      default:
        // Full, warm two-note bell (D5 -> A5): a soft mallet attack, a rich
        // harmonic body and a short sub-octave so it carries on laptop
        // speakers instead of sounding thin. Three gently decaying strikes
        // keep the chime present for about three seconds without turning it
        // into an alarm.
        const strike = (start, gain) => {
          note({ freq: 587.33, start, dur: 0.72, type: "sine", vol: v * 0.90 * gain, attack: 0.004, release: 0.72, filter: 5200, pan: -0.04, partials: [[1, 1], [2, 0.34], [3, 0.16], [4, 0.07]] });
          note({ freq: 293.66, start, dur: 0.42, type: "sine", vol: v * 0.34 * gain, attack: 0.008, release: 0.42, filter: 1500, partials: [[1, 1]] });
          note({ freq: 880, start: start + 0.13, dur: 0.9, type: "sine", vol: v * 0.82 * gain, attack: 0.004, release: 0.9, filter: 5600, pan: 0.04, partials: [[1, 1], [2, 0.30], [3, 0.14], [4, 0.06]] });
        };
        strike(0, 1);
        strike(0.95, 0.72);
        strike(1.9, 0.52);
    }
  }

  const LANGS = { en: ["en"], ne: ["ne"], hi: ["hi", "en-IN", "en"] };
  const FEMALE_HINTS = ["female", "zira", "samantha", "victoria", "karen", "moira", "tessa", "fiona", "veena", "aditi", "ava", "susan", "kate", "emily", "serena", "heera", "lekha", "aria", "jenny", "hazel", "allison", "ariaonline", "eva", "paulina", "amelie", "denise", "joanna", "kimberly", "salli", "amy", "raveena", "priya", "kalpana", "neerja", "susan", "zhiyu", "huihui", "yaoyao"];
  const MALE_HINTS = ["male", "david", "daniel", "mark", "alex", "fred", "thomas", "rishi", "ravi", "hemant", "george", "james", "roger", "guy", "ryan", "davis", "christopher", "brian", "neil", "arthur", "arun", "madhur", "valluvar", "jian", "kangkang", "yunyang"];

  function voices() {
    try {
      const vs = window.speechSynthesis.getVoices() || [];
      if (vs.length) voicesCache = vs;
      return vs.length ? vs : (voicesCache || []);
    } catch (e) { return voicesCache || []; }
  }
  let voicesCache = null;

  /* Wait (briefly) for the browser to publish its voice list. Speaking before
     voices load is a top cause of "wrong voice" bugs. */
  function awaitVoices(timeoutMs) {
    return new Promise((resolve) => {
      try {
        if (voices().length) return resolve(voices());
      } catch (e) { return resolve([]); }
      let done = false;
      let handler = null;
      let prev = null;
      const finish = () => {
        if (done) return;
        done = true;
        clearTimeout(t);
        try {
          if (handler && window.speechSynthesis.onvoiceschanged === handler) {
            window.speechSynthesis.onvoiceschanged = prev;
          }
        } catch (e) {}
        try { resolve(voices()); } catch (e) { resolve([]); }
      };
      const t = setTimeout(finish, timeoutMs || 2000);
      try {
        prev = window.speechSynthesis.onvoiceschanged;
        handler = () => {
          try { if (typeof prev === "function") prev(); } catch (e) {}
          finish();
        };
        window.speechSynthesis.onvoiceschanged = handler;
      } catch (e) { clearTimeout(t); finish(); }
    });
  }

  function voiceGenderOf(v) {
    try {
      if (typeof WR !== "undefined" && WR.detectVoiceGender) {
        const g = WR.detectVoiceGender(v && v.name);
        if (g) return g;
      }
    } catch (e) {}
    const n = String((v && v.name) || "").toLowerCase();
    if (FEMALE_HINTS.some((h) => n.indexOf(h) >= 0)) return "female";
    if (MALE_HINTS.some((h) => n.indexOf(h) >= 0) && !FEMALE_HINTS.some((h) => n.indexOf(h) >= 0)) return "male";
    return null;
  }

  function pickVoice(language, gender) {
    const vs = voices();
    const prefs = LANGS[language] || [language, "en"];
    const wantG = (gender === "female" || gender === "male") ? gender : null;
    for (const p of prefs) {
      const match = vs.filter((v) => v.lang && v.lang.toLowerCase().startsWith(p.toLowerCase()));
      if (!match.length) continue;
      if (!wantG) {
        match.sort((a, b) => voiceScore(b, null) - voiceScore(a, null));
        return match[0];
      }
      const pool = match.filter((v) => voiceGenderOf(v) === wantG);
      if (!pool.length) continue; // never fall back to the opposite gender in this language
      pool.sort((a, b) => voiceScore(b, wantG) - voiceScore(a, wantG));
      return pool[0];
    }
    if (wantG) {
      const crossLang = vs.filter((v) => voiceGenderOf(v) === wantG);
      if (crossLang.length) {
        crossLang.sort((a, b) => voiceScore(b, wantG) - voiceScore(a, wantG));
        return crossLang[0];
      }
      return null; // no voice of the requested gender: caller must NOT speak another gender
    }
    return null;
  }

  function voiceScore(v, gender) {
    const n = (v.name || "").toLowerCase();
    let s = 0;
    if (!v.localService) s += 10; // network voices = clean high-quality TTS, strongly preferred
    if (n.includes("natural")) s += 6;
    if (n.includes("neural")) s += 5;
    if (n.includes("google")) s += 4;
    if (n.includes("enhanced") || n.includes("premium")) s += 3;
    if (n.includes("online")) s += 2;
    if (gender === "male") {
      if (n.includes("male")) s += 4;
      if (n.includes("david") || n.includes("george") || n.includes("ravi") || n.includes("rishi") || n.includes("hemant")) s += 2;
    }
    if (gender === "female") {
      if (n.includes("female")) s += 4;
      if (n.includes("aria") || n.includes("jenny") || n.includes("zira") || n.includes("samantha")) s += 2;
    }
    return s;
  }

  /* Normalization + pacing live in shared.js (WR.*); thin wrappers here. */
  function normalizeSpeechText(text) {
    try {
      if (typeof WR !== "undefined" && WR.normalizeSpeechText) return WR.normalizeSpeechText(text);
    } catch (e) {}
    return String(text == null ? "" : text).trim();
  }

  function utteranceLang(language, voice) {
    if (voice && voice.lang) return voice.lang;
    try {
      if (typeof WR !== "undefined" && WR.ttsLang) return WR.ttsLang(language) || "en-US";
    } catch (e) {}
    if (!language || language === "en") return "en-US"; // clear, natural English pronunciation
    return language;
  }

  function speak(text, voice) {
    return speakAsync(text, voice || {}).catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
  }

  async function speakAsync(text, voice) {
    voice = voice || {};
    const spoken = normalizeSpeechText(text);
    if (!spoken) return { ok: false, error: "empty text" };
    try { window.speechSynthesis.cancel(); } catch (e) {}
    await awaitVoices(2000);
    const wantG = (voice.gender === "female" || voice.gender === "male") ? voice.gender : null;
    const v = pickVoice(voice.language || "en", voice.gender || "default")
      || pickVoice("en", voice.gender || "default"); // fallback: English voice
    if (!v && !wantG) {
      const any = voices()[0] || null;
      if (!any) return { ok: false, error: "no-voices" };
      return speakWith(any, spoken, voice, wantG);
    }
    if (!v) return { ok: false, error: "no-voice-for-gender", gender: voice.gender };
    return speakWith(v, spoken, voice, wantG);
  }

  function speakWith(v, spoken, voice, wantG) {
    const u = new SpeechSynthesisUtterance(spoken);
    u.voice = v; u.lang = v.lang;
    const gender = voice.gender || "default";
    let optRate = 0.86, optPitch = 1.0;
    try {
      if (typeof WR !== "undefined" && WR.voiceRate) {
        optRate = WR.voiceRate(voice.speed, gender);
        optPitch = WR.voicePitch(gender);
      } else {
        optRate = voice.speed === "slow" ? 0.68 : voice.speed === "fast" ? 1.06 : 0.86;
        optPitch = gender === "male" ? 0.82 : 1.0;
      }
    } catch (e) {}
    u.rate = optRate;
    try { u.pitch = optPitch; } catch (e) {}
    const vn = Number(voice.volume);
    u.volume = isFinite(vn) ? Math.min(1, Math.max(0, vn / 100)) : 0.8;
    try {
      window.speechSynthesis.speak(u);
    } catch (e) {
      return { ok: false, error: String(e) };
    }
    return { ok: true, voice: v.name, genderMatched: !wantG || voiceGenderOf(v) === wantG };
  }

  function listVoices() {
    const vs = voices().map((v) => ({ name: v.name, lang: v.lang, local: v.localService }));
    return { ok: true, count: vs.length, voices: vs.slice(0, 60) };
  }

  if (window.speechSynthesis) {
    window.speechSynthesis.onvoiceschanged = () => voices();
    voices();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.target !== "offscreen") return false;
    try {
      if (msg.action === "playSound") { playSound(msg.name, msg.volume); sendResponse({ ok: true }); }
      else if (msg.action === "speak") { speak(msg.text, msg.voice || {}).then(sendResponse); return true; }
      else if (msg.action === "stopSound") { stopSound(); sendResponse({ ok: true }); }
      else if (msg.action === "stopSpeech") { try { window.speechSynthesis.cancel(); } catch (e) {} sendResponse({ ok: true }); }
      else if (msg.action === "listVoices") { sendResponse(listVoices()); }
      else sendResponse({ ok: false, error: "unknown action" });
    } catch (e) { sendResponse({ ok: false, error: String(e) }); }
    return true;
  });
})();
