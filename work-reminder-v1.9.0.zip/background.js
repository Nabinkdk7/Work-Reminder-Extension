/* Work Reminder background service worker.
   - owns reminders/settings in chrome.storage.local
   - schedules chrome.alarms for every enabled reminder (persist across popup close)
   - fires notification + sound + voice on trigger
   - handles snooze / done / dismiss from notification buttons
   - rebuilds alarms on install/startup (browser restart, extension restart) */

importScripts("shared.js");

const WR = self.WR;

/* ---------------- storage ---------------- */

/* All read-modify-write operations go through this queue. Chrome can deliver
   two events at once (a notification button + the popup saving a reminder, for
   example); without serialization the later write silently loses the first. */
let mutationTail = Promise.resolve();
function runMutation(fn) {
  // Every state change is queued, even if an earlier one failed. This is what
  // prevents a notification button and a popup save from overwriting each
  // other's fresh read. Do not call runMutation() from inside another mutation.
  const next = mutationTail.then(fn, fn);
  mutationTail = next.catch(() => {});
  return next;
}

function parse(items) {
  const rawReminders = Array.isArray(items.reminders) ? items.reminders : [];
  return {
    reminders: rawReminders.slice(0, 2000).map((r, i) => WR.normalizeReminder(r, "r_legacy_" + i)),
    settings: WR.normalizeSettings(items.settings),
    office: WR.normalizeOffice(items.office),
    seeded: !!items.seeded,
    seedVersion: items.seedVersion || 0,
    pendingUpdate: items.pendingUpdate || null,
    updateNotifiedVersion: items.updateNotifiedVersion || null,
    installedNotifiedFor: items.installedNotifiedFor || null,
    updateCheckedAt: items.updateCheckedAt || 0,
    updateAttemptedAt: items.updateAttemptedAt || 0,
    screen: WR.normalizeScreen(items.screen),
  };
}

function readStateOnce() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["reminders", "settings", "office", "seeded", "seedVersion", "pendingUpdate", "updateNotifiedVersion", "installedNotifiedFor", "updateCheckedAt", "updateAttemptedAt", "screen"], (items) => {
      const err = chrome.runtime.lastError;
      if (err) {
        try { console.warn("Work Reminder: storage read failed", err.message); } catch (e) {}
        reject(new Error((err && err.message) || "storage read failed"));
        return;
      }
      resolve(parse(items || {}));
    });
  });
}

/* Never turn a transient read error into an empty default state: a following
   save would then erase the user's real schedule. Retry once, then fail loudly. */
function readState() {
  return readStateOnce().catch(() => new Promise((resolve) => setTimeout(resolve, 60)).then(readStateOnce));
}

/* Always persist normalized reminders so a bad write can never poison storage.
   Duplicate ids from a hand-edited/imported file get a fresh id. */
function writeReminders(reminders) {
  const seen = new Set();
  const clean = (Array.isArray(reminders) ? reminders.slice(0, 2000) : []).map((r) => {
    const n = WR.normalizeReminder(r);
    if (seen.has(n.id)) n.id = WR.uid();
    seen.add(n.id);
    return n;
  });
  return writeState({ reminders: clean }).then(() => clean);
}

function writeState(patch) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(patch, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        try { console.warn("Work Reminder: storage write failed", err.message); } catch (e) {}
        reject(new Error((err && err.message) || "storage write failed"));
      } else {
        resolve(true);
      }
    });
  });
}

/* ---------------- toolbar clock ----------------
   The toolbar icon uses the original logo artwork, scaled up slightly so it
   fills the whole icon area edge-to-edge. The live local time is rendered by
   Chrome as a native badge in the corner, so it stays crisp at every size and
   nothing is drawn on top of the logo. Turn it off in Settings to hide the
   badge and go back to the untouched PNGs. */
const ICON_SIZES = [16, 32, 48, 128];
const ICON_PATHS = {
  16: "icons/icon16.png",
  32: "icons/icon32.png",
  48: "icons/icon48.png",
  128: "icons/icon128.png",
};

// The artwork is drawn slightly oversized and clipped, so the violet tile
// touches the icon edges instead of floating inside them.
const LOGO_ZOOM = 1.08;

function actionCall(fn, arg) {
  try {
    const p = chrome.action && chrome.action[fn] && chrome.action[fn](arg);
    if (p && typeof p.catch === "function") p.catch(() => {});
  } catch (e) { /* action API is best-effort */ }
}

let logoBitmap = null;
let logoLoadFailed = false;
let logoImageData = null;
let iconApplied = false;

async function getLogoBitmap() {
  if (logoBitmap) return logoBitmap;
  if (logoLoadFailed) return null;
  try {
    const res = await fetch(chrome.runtime.getURL("icons/icon128.png"));
    const blob = await res.blob();
    logoBitmap = await createImageBitmap(blob);
    return logoBitmap;
  } catch (e) {
    logoLoadFailed = true;
    return null;
  }
}

function drawToolbarLogo(size, logo) {
  const canvas = new OffscreenCanvas(size, size);
  const g = canvas.getContext("2d");
  g.imageSmoothingEnabled = true;
  g.imageSmoothingQuality = "high";
  const d = size * LOGO_ZOOM;
  const off = (size - d) / 2;
  g.drawImage(logo, off, off, d, d);
  return g.getImageData(0, 0, size, size);
}

function iconTimeParts(now, hourFormat) {
  const h24 = now.getHours();
  const m = now.getMinutes();
  let hh;
  if (hourFormat === 24) hh = WR.pad(h24);
  else { hh = String(h24 % 12); if (hh === "0") hh = "12"; }
  const mm = WR.pad(m);
  return { h24, m, hh, mm, label: hh + ":" + mm };
}

// Chrome only fits about four characters in a badge.
function badgeTime(parts) {
  const withColon = parts.hh + ":" + parts.mm;
  return withColon.length <= 4 ? withColon : parts.hh + parts.mm;
}

async function updateActionClock() {
  if (!chrome.action || !chrome.action.setIcon) return;
  try {
    const { settings } = await readState();
    if (settings.iconClock === false) {
      actionCall("setIcon", { path: ICON_PATHS });
      actionCall("setBadgeText", { text: "" });
      actionCall("setTitle", { title: "Work Reminder" });
      iconApplied = false;
      return;
    }

    // Edge-to-edge logo, then Chrome draws the time on top as a native badge.
    // The logo is static; rasterizing it once per worker avoids doing four
    // canvas draws every single minute just to update the badge.
    if (!iconApplied) {
      const logo = typeof OffscreenCanvas === "undefined" ? null : await getLogoBitmap();
      if (logo) {
        if (!logoImageData) {
          // Build the whole set first: if one rasterization fails we must not
          // cache a half-populated object and then reuse it forever.
          const next = {};
          for (const s of ICON_SIZES) next[s] = drawToolbarLogo(s, logo);
          logoImageData = next;
        }
        actionCall("setIcon", { imageData: logoImageData });
        iconApplied = true;
      } else {
        actionCall("setIcon", { path: ICON_PATHS });
        iconApplied = false;
      }
    }

    const parts = iconTimeParts(new Date(), settings.hourFormat);
    actionCall("setBadgeText", { text: badgeTime(parts) });
    actionCall("setBadgeBackgroundColor", { color: "#1e293b" });
    if (chrome.action && chrome.action.setBadgeTextColor) actionCall("setBadgeTextColor", { color: "#ffffff" });
    actionCall("setTitle", { title: "Work Reminder — " + parts.label });
  } catch (e) { /* toolbar icon is best-effort */ }
}

/* ---------------- offscreen / voice / sound ---------------- */

let creatingOffscreen = null;
async function ensureOffscreen() {
  if (!chrome.offscreen) return false;
  try {
    const has = await chrome.offscreen.hasDocument();
    if (has) return true;
  } catch (e) { /* fall through to create */ }
  if (creatingOffscreen) { try { await creatingOffscreen; return true; } catch (e) { return false; } }
  try {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Play reminder sounds and speak reminders with text-to-speech.",
    });
  } catch (e) {
    creatingOffscreen = null;
    return false;
  }
  try { await creatingOffscreen; return true; } catch (e) { return false; } finally { creatingOffscreen = null; }
}

function offscreenMessage(msg) {
  return new Promise((resolve) => {
    (async () => {
      try {
        if (!(await ensureOffscreen())) return resolve({ ok: false });
        let settled = false;
        let t = 0;
        const done = (value) => { if (!settled) { settled = true; clearTimeout(t); resolve(value); } };
        // Never let a stuck offscreen document block reminder re-arming.
        t = setTimeout(() => done({ ok: false, error: "timeout" }), 8000);
        chrome.runtime.sendMessage(Object.assign({ target: "offscreen" }, msg), (resp) => {
          if (chrome.runtime.lastError) return done({ ok: false });
          done(resp || { ok: false });
        });
      } catch (e) {
        resolve({ ok: false, error: (e && e.message) || "offscreen unavailable" });
      }
    })();
  });
}

const FEMALE_NAME = ["female", "zira", "samantha", "victoria", "karen", "moira", "tessa", "fiona", "veena", "aditi", "ava", "susan", "kate", "emily", "serena", "heera", "lekha", "aria", "jenny", "hazel", "allison", "eva", "paulina", "amelie", "denise", "joanna", "kimberly", "salli", "amy", "raveena", "priya", "kalpana", "neerja", "zhiyu", "huihui", "yaoyao"];
const MALE_NAME = ["male", "david", "daniel", "mark", "alex", "fred", "thomas", "rishi", "ravi", "hemant", "george", "james", "roger", "guy", "ryan", "davis", "christopher", "brian", "neil", "arthur", "arun", "madhur", "valluvar", "jian", "kangkang", "yunyang"];

function isVoiceGender(v, gender) {
  if (v.gender === gender) return true;
  if (v.gender && v.gender !== "default") return false;
  try {
    if (WR && WR.detectVoiceGender) {
      const g = WR.detectVoiceGender(v.voiceName);
      if (g) return g === gender;
    }
  } catch (e) {}
  const n = (v.voiceName || "").toLowerCase();
  if (gender === "female") return FEMALE_NAME.some((h) => n.indexOf(h) >= 0);
  if (gender === "male") return MALE_NAME.some((h) => n.indexOf(h) >= 0) && n.indexOf("female") < 0;
  return true;
}

function ttsVoiceScore(v, gender) {
  const n = (v.voiceName || "").toLowerCase();
  let s = 0;
  if (v.remote) s += 10; // network voices = clean high-quality TTS, strongly preferred
  if (n.indexOf("natural") >= 0) s += 6;
  if (n.indexOf("neural") >= 0) s += 5;
  if (n.indexOf("google") >= 0) s += 4;
  if (n.indexOf("enhanced") >= 0 || n.indexOf("premium") >= 0) s += 3;
  if (n.indexOf("online") >= 0) s += 2;
  if (gender === "male") {
    if (n.indexOf("male") >= 0) s += 4;
    if (/david|george|ravi|rishi|hemant|guy|james|fred|google uk english male/.test(n)) s += 2;
  }
  if (gender === "female") {
    if (n.indexOf("female") >= 0) s += 4;
    if (/aria|jenny|zira|samantha|ava|susan|amy|google us english|google uk english female|sonia/.test(n)) s += 2;
  }
  return s;
}

function pickTtsVoice(cfg) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (v) => { if (!settled) { settled = true; clearTimeout(timer); resolve(v); } };
    // If the TTS engine never answers we must not block the reminder forever.
    const timer = setTimeout(() => finish(null), 2000);
    try {
      chrome.tts.getVoices((voices) => {
        if (chrome.runtime.lastError || !Array.isArray(voices) || !voices.length) return finish(null);
        const lang = (cfg && cfg.language && cfg.language !== "system") ? cfg.language : "en";
        const want = (v) => v.lang && v.lang.toLowerCase().startsWith(lang.toLowerCase());
        let pool = voices.filter(want);
        if (!pool.length) pool = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith("en"));
        if (!pool.length) pool = voices;
        const gender = cfg && cfg.gender;
        let hinted = pool;
        if (gender && gender !== "default") {
          hinted = pool.filter((v) => isVoiceGender(v, gender));
          if (!hinted.length) hinted = voices.filter((v) => isVoiceGender(v, gender)); // any lang as last try
          if (!hinted.length) return finish(null); // don't pick the opposite gender
        }
        const ttsGender = cfg && cfg.gender;
        hinted.sort((a, b) => ttsVoiceScore(b, ttsGender) - ttsVoiceScore(a, ttsGender));
        finish(hinted[0] ? hinted[0].voiceName : null);
      });
    } catch (e) { finish(null); }
  });
}

/* Normalize text before speaking so English is pronounced clearly and naturally.
   Only the spoken copy is changed — the stored reminder text is untouched.
   (Single source of truth lives in shared.js as WR.normalizeSpeechText.) */
function normalizeSpeechText(text) {
  return WR.normalizeSpeechText(text);
}

function ttsLang(lang) {
  return WR.ttsLang(lang);
}

function speak(text, voiceCfg) {
  // Chain: chrome.tts with an explicitly gender-verified voice -> Web Speech
  // with strict gender matching -> plain default voice (last resort only).
  // A bare chrome.tts gender flag is deliberately NOT used: it is unreliable
  // and was the cause of "female plays male".
  return new Promise(async (resolve) => {
    try {
    const spoken = normalizeSpeechText(text);
    if (!spoken) return resolve({ ok: false, error: "empty text" });
    const gender = (voiceCfg && voiceCfg.gender) || "default";
    const wantG = (gender === "male" || gender === "female") ? gender : null;
    const baseOpts = () => ({
      rate: WR.voiceRate(voiceCfg && voiceCfg.speed, gender),
      pitch: WR.voicePitch(gender),
      volume: Math.min(1, Math.max(0, (voiceCfg && voiceCfg.volume != null ? voiceCfg.volume : 80) / 100)),
      enqueue: false,
    });
    const ttsSpeak = (opts) => new Promise((res) => {
      let settled = false;
      const finish = (r) => { if (!settled) { settled = true; clearTimeout(timer); res(r); } };
      // The callback usually fires when speech ENDS. A stuck engine must not
      // hold up the rest of the reminder, so treat a timeout as "started".
      const timer = setTimeout(() => finish({ ok: true, engine: "chrome.tts", voiceName: opts.voiceName || "default", timedOut: true }), 15000);
      try {
        chrome.tts.speak(spoken, opts, () => {
          if (chrome.runtime.lastError) return finish({ ok: false });
          finish({ ok: true, engine: "chrome.tts", voiceName: opts.voiceName || "default" });
        });
      } catch (e) { finish({ ok: false }); }
    });
    const canTts = chrome.tts && typeof chrome.tts.speak === "function";
    if (canTts) {
      const opts = baseOpts();
      if (voiceCfg && voiceCfg.language && voiceCfg.language !== "system") opts.lang = ttsLang(voiceCfg.language);
      const voiceName = await pickTtsVoice(voiceCfg);
      if (voiceName) {
        opts.voiceName = voiceName;
        const r = await ttsSpeak(opts);
        if (r.ok) return resolve(r);
      } else if (!wantG) {
        const r = await ttsSpeak(opts);
        if (r.ok) return resolve(r);
      }
      // wantG but no gender-verified chrome.tts voice: skip bare-gender speak, try Web Speech.
    }
    const res = await offscreenMessage({ action: "speak", text: spoken, voice: voiceCfg || {} });
    if (res && res.ok) return resolve(res);
    // Last resort for a gender-agnostic request: speak with the system default.
    // For an explicit male/female request, never substitute the other gender —
    // the Test Voice panel explains when the requested voice is missing.
    if (canTts && !wantG) {
      const opts = baseOpts();
      if (voiceCfg && voiceCfg.language && voiceCfg.language !== "system") opts.lang = ttsLang(voiceCfg.language);
      return resolve(await ttsSpeak(opts));
    }
    resolve(res || { ok: false, error: wantG ? "no-voice-for-gender" : "no-voice" });
    } catch (e) {
      resolve({ ok: false, error: (e && e.message) || "voice failed" });
    }
  });
}

function playSound(name, volume) {
  return offscreenMessage({ action: "playSound", name, volume });
}

/* Stop anything already speaking/ringing. DND must silence an alert that is
   already in progress, not just prevent the next one. */
async function stopAllAudio() {
  try { chrome.tts.stop(); } catch (e) {}
  await Promise.allSettled([
    offscreenMessage({ action: "stopSpeech" }),
    offscreenMessage({ action: "stopSound" }),
  ]);
}

/* ---------------- update checker ---------------- */

const UPDATE_OWNER = "Nabinkdk7";
const UPDATE_REPO = "Work-Reminder-Extension";
// Version source: the latest GitHub Release (keeps the repo clean: ZIP + README only).
const UPDATE_API_URL = "https://api.github.com/repos/" + UPDATE_OWNER + "/" + UPDATE_REPO + "/releases/latest";
const REPO_URL = "https://github.com/" + UPDATE_OWNER + "/" + UPDATE_REPO;
const UPDATE_CHECK_ALARM = "wr-update-check";
const UPDATE_CHECK_MINUTES = 720; // automatic check every 12 hours
const UPDATE_HOSTS = new Set([
  "github.com", "www.github.com", "api.github.com", "codeload.github.com",
  "objects.githubusercontent.com", "raw.githubusercontent.com",
  "github-releases.githubusercontent.com",
]);

function safeUpdateUrl(raw) {
  try {
    const u = new URL(String(raw || ""));
    return u.protocol === "https:" && UPDATE_HOSTS.has(u.hostname.toLowerCase());
  } catch (e) {
    return false;
  }
}

function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x < y) return -1;
    if (x > y) return 1;
  }
  return 0;
}

async function ensureUpdateCheck() {
  try {
    const all = await chrome.alarms.getAll();
    if (!all.some((a) => a.name === UPDATE_CHECK_ALARM)) {
      await chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: UPDATE_CHECK_MINUTES });
    }
  } catch (e) {}
}

function notifyUpdateAvailable(info) {
  const id = "wr-update-available";
  try {
    const p = chrome.notifications.create(id, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Work Reminder update available",
      message: "Version " + info.version + " is ready." + (info.notes ? " " + info.notes : ""),
      priority: 1,
      buttons: [{ title: "Download update" }, { title: "Later" }],
    });
    if (p && typeof p.catch === "function") p.catch(() => {});
  } catch (e) {}
  return id;
}

function notifyUpdateInstalled(version) {
  try {
    const p = chrome.notifications.create("wr-update-installed", {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Work Reminder updated",
      message: "Successfully updated to version " + version + ".",
      priority: 1,
    });
    if (p && typeof p.catch === "function") p.catch(() => {});
  } catch (e) {}
}

/* Map a GitHub Release object to {version, notes, url}. */
function parseRelease(rel) {
  if (!rel || typeof rel.tag_name !== "string") return null;
  const version = rel.tag_name.replace(/^v/i, "");
  if (!version) return null;
  let url = REPO_URL + "/releases/latest";
  const assets = Array.isArray(rel.assets) ? rel.assets : [];
  const zipAsset = assets.find((a) => /\.zip$/i.test(a.name || ""));
  if (zipAsset && zipAsset.browser_download_url && safeUpdateUrl(zipAsset.browser_download_url)) {
    url = zipAsset.browser_download_url;
  }
  let notes = typeof rel.body === "string" ? rel.body.trim() : "";
  if (notes.length > 300) notes = notes.slice(0, 297) + "...";
  return { version, notes, url };
}

/* Fallback version source: scan the repo file list for the newest
   work-reminder-vX.Y.Z.zip. Works with a ZIP+README-only repo and needs
   no release to be published. */
const CONTENTS_API_URL = "https://api.github.com/repos/" + UPDATE_OWNER + "/" + UPDATE_REPO + "/contents/";
function parseRepoContents(items) {
  if (!Array.isArray(items)) return null;
  let best = null;
  for (const it of items) {
    if (!it || it.type !== "file") continue;
    const m = /^work-reminder-v(\d+(?:\.\d+)*)\.zip$/i.exec(it.name || "");
    if (!m) continue;
    if (!best || compareVersions(m[1], best.version) > 0) {
      const raw = it.download_url || "";
      best = { version: m[1], notes: "", url: safeUpdateUrl(raw) ? raw : REPO_URL + "/releases/latest" };
    }
  }
  return best;
}

async function fetchJson(url) {
  const ctl = new AbortController();
  const timer = setTimeout(() => { try { ctl.abort(); } catch (e) {} }, 8000);
  try {
    const res = await fetch(url, {
      cache: "no-store",
      headers: { "Accept": "application/vnd.github+json" },
      signal: ctl.signal,
    });
    if (!res || !res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchRemoteVersion() {
  // Preferred: latest GitHub Release (has notes + attached asset).
  const rel = await fetchJson(UPDATE_API_URL);
  const fromRelease = parseRelease(rel);
  if (fromRelease) return fromRelease;
  // Fallback: newest versioned ZIP in the repo itself.
  const items = await fetchJson(CONTENTS_API_URL);
  return parseRepoContents(items);
}

/* Check GitHub for a newer release. Notifies ONLY when an update is
   available (once per version) — never when already up to date. */
async function checkForUpdates(manual) {
  const current = chrome.runtime.getManifest().version;
  const remote = await fetchRemoteVersion();
  if (!remote) {
    return { ok: false, error: "unreachable", current };
  }
  const result = {
    ok: true,
    current,
    latest: remote.version,
    notes: remote.notes || "",
    url: remote.url || REPO_URL,
    update: compareVersions(current, remote.version) < 0,
    checkedAt: Date.now(),
  };
  // A manual "Check now" and the 12-hour alarm can overlap. Serialize the
  // state change so the update notification is shown at most once per version.
  const notify = await runMutation(async () => {
    const state = await readState();
    if (result.update) {
      const alreadyNotified = state.updateNotifiedVersion === remote.version;
      await writeState({
        pendingUpdate: { version: remote.version, notes: result.notes, url: result.url },
        updateNotifiedVersion: remote.version,
        updateCheckedAt: result.checkedAt,
      });
      return !alreadyNotified;
    }
    const patch = { updateCheckedAt: result.checkedAt };
    // Up to date (or ahead): clear any stale pending update silently.
    if (state.pendingUpdate && compareVersions(current, state.pendingUpdate.version) >= 0) {
      patch.pendingUpdate = null;
    }
    await writeState(patch);
    return false;
  });
  if (notify) notifyUpdateAvailable({ version: remote.version, notes: result.notes });
  return result;
}

/* After a restart, detect a just-installed update and confirm it once. */
async function checkInstalledUpdate() {
  try {
    const current = chrome.runtime.getManifest().version;
    const state = await readState();
    if (state.pendingUpdate && compareVersions(current, state.pendingUpdate.version) >= 0) {
      if (state.installedNotifiedFor !== current) {
        notifyUpdateInstalled(current);
        await writeState({ pendingUpdate: null, installedNotifiedFor: current });
      } else {
        await writeState({ pendingUpdate: null });
      }
    }
  } catch (e) {}
}

/* ---------------- scheduling ---------------- */

const ALARM_PREFIX = "wr-rem-";

async function scheduleReminder(rem) {
  if (!rem || !rem.id) return;
  try { await chrome.alarms.clear(ALARM_PREFIX + rem.id); } catch (e) {}
  if (rem.enabled === false) return;
  const next = WR.nextOccurrence(rem, new Date());
  if (!next) return;
  try {
    await chrome.alarms.create(ALARM_PREFIX + rem.id, { when: next.getTime() });
  } catch (e) { /* alarm time invalid — skip */ }
}

async function rebuildAlarms() {
  const { reminders, settings } = await readState();
  await chrome.alarms.clearAll();
  await ensureTick();
  await ensureUpdateCheck();
  if (!settings.enabled) return;
  for (const r of reminders) await scheduleReminder(r);
}

/* Non-destructive reconciliation used on every service-worker wake-up.
   It creates missing alarms, drops alarms for deleted/disabled reminders and
   leaves existing alarms (including an active snooze) untouched. */
async function syncAlarms() {
  const { reminders, settings } = await readState();
  await ensureTick();
  await ensureUpdateCheck();
  let existing = [];
  try { existing = await chrome.alarms.getAll(); } catch (e) {}
  const byName = new Map(existing.map((a) => [a.name, a]));
  const wanted = new Set();
  if (settings.enabled) {
    for (const r of reminders) {
      if (r.enabled === false) continue;
      const next = WR.nextOccurrence(r, new Date());
      if (!next) continue;
      const name = ALARM_PREFIX + r.id;
      wanted.add(name);
      const have = byName.get(name);
      const target = next.getTime();
      // Rebuild missing alarms, alarms whose time drifted (timezone change,
      // clock correction), or a stale alarm left in the past by a snooze.
      const haveAt = have ? (have.scheduledTime || 0) : 0;
      const now = Date.now();
      const near = have && haveAt >= now - 120000 && haveAt <= now + 120000;
      const drifted = have && !near && Math.abs(haveAt - target) > 120000;
      const stalePast = have && haveAt < now - 120000;
      if (!have || drifted || stalePast) {
        try { await chrome.alarms.create(name, { when: target }); } catch (e) {}
      }
    }
  }
  for (const a of existing) {
    if (a.name.indexOf(ALARM_PREFIX) === 0 && !wanted.has(a.name)) {
      try { await chrome.alarms.clear(a.name); } catch (e) {}
    }
  }
}

/* ---------------- firing ---------------- */

const NOTIF_PREFIX = "notif-";
const UPDATE_NOTIF_ID = "wr-update-available";

/* The reminder id is part of the notification id so Done/Snooze keeps working
   even after Chrome has recycled the service worker (the in-memory map would
   be gone by then). The timestamp suffix is stripped with a greedy match, so
   ids may themselves contain dashes. */
function notificationIdFor(remId) {
  return NOTIF_PREFIX + remId + "-" + Date.now();
}
function reminderIdFromNotification(notifId) {
  if (typeof notifId !== "string" || notifId.indexOf(NOTIF_PREFIX) !== 0) return null;
  const body = notifId.slice(NOTIF_PREFIX.length);
  const m = /^(.+)-\d+$/.exec(body);
  return m ? m[1] : null;
}

const FIRING = new Set(); // reminders currently playing, avoids double-fires

async function fireReminder(rem, opts) {
  if (!rem || !rem.id) return;
  const force = !!(opts && opts.force);
  const scheduled = opts && opts.scheduled ? +opts.scheduled : 0;
  if (!force && FIRING.has(rem.id)) return;
  FIRING.add(rem.id);
  try {
    const plan = await prepareReminderFire(rem, force, scheduled);
    if (plan) await deliverReminder(plan.rem, plan.settings);
  } catch (e) {
    try { console.warn("Work Reminder: could not fire reminder", e && e.message); } catch (e2) {}
  } finally {
    FIRING.delete(rem.id);
  }
}

/* State change and delivery are deliberately separate. The mutation lock is
   held only for the fast read/update/write; a slow speech engine must never
   block the popup or another alarm. */
function prepareReminderFire(rem, force, scheduled) {
  return runMutation(async () => {
    const { settings, reminders } = await readState();
    if (!settings.enabled) return null;
    const cur = reminders.find((r) => r.id === rem.id) || WR.normalizeReminder(rem);
    if (cur.enabled === false && !force) return null;
    // A safety-net tick and the real alarm can land together; only alert once.
    if (!force && cur.lastFiredAt && Date.now() - cur.lastFiredAt < 5000) return null;
    // A stale alarm must not jump an active snooze or a reminder already
    // completed today. Re-arm the correct occurrence and stay quiet. The snooze
    // alarm itself is allowed through even if the test/clock jumps ahead.
    const isSnoozeAlarm = !!(scheduled && cur.snoozedUntil && Math.abs(scheduled - +cur.snoozedUntil) < 5000);
    if (!force && !isSnoozeAlarm && cur.snoozedUntil && +cur.snoozedUntil > Date.now() + 1000) {
      await scheduleReminder(cur);
      return null;
    }
    if (!force && cur.lastCompletedDate === WR.todayKey(new Date())) {
      await scheduleReminder(cur);
      return null;
    }

    // Do Not Disturb: stay completely silent. Recurring reminders move on to
    // their next slot; a one-off is deferred to the moment the pause ends so it
    // is never lost.
    if (WR.isPaused(settings)) {
      if (cur.repeat === "once") {
        cur.snoozedUntil = Math.max(+settings.pausedUntil || 0, Date.now() + 60000);
        cur.dndDeferred = true;
        const idx = reminders.findIndex((r) => r.id === cur.id);
        if (idx >= 0) reminders[idx] = cur;
        await writeReminders(reminders);
        await scheduleReminder(cur);
      } else {
        // Mark today's occurrence as handled (silently) so the safety-net tick
        // doesn't keep re-processing it for the next ten minutes.
        cur.lastFiredAt = Date.now();
        cur.dndDeferred = false;
        const idx = reminders.findIndex((r) => r.id === cur.id);
        if (idx >= 0) reminders[idx] = cur;
        await writeReminders(reminders);
        await scheduleReminder(cur);
      }
      return null;
    }

    cur.lastFiredAt = Date.now();
    cur.snoozedUntil = 0;
    cur.dndDeferred = false;
    if (cur.repeat === "once") cur.enabled = false;
    const idx = reminders.findIndex((r) => r.id === cur.id);
    if (idx >= 0) reminders[idx] = cur;
    await writeReminders(reminders);
    // Re-arm BEFORE sound/voice: a slow or stuck speech engine must never cost
    // the next occurrence. A one-off alarm is spent and needs no re-arm.
    if (cur.repeat !== "once") await scheduleReminder(cur);
    return { rem: cur, settings };
  });
}

async function deliverReminder(cur, settings) {
  if (settings.notificationsEnabled && cur.notificationEnabled !== false) {
    try {
      await chrome.notifications.create(notificationIdFor(cur.id), {
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "Work Reminder — " + (cur.title || "Reminder"),
        message: cur.message || "",
        priority: 2,
        requireInteraction: true,
        silent: true, // the extension plays its own richer sound
        buttons: [
          { title: "Done" },
          { title: "Snooze " + (settings.defaultSnooze || 5) + " min" },
        ],
      });
    } catch (e) { /* notifications unavailable */ }
  }

  if (cur.sound && cur.sound !== "none") await playSound(cur.sound, settings.sound.volume);

  const voiceOn = settings.voiceEnabled && cur.voiceEnabled !== false;
  if (voiceOn) {
    // Speak the exact text saved in the reminder's message field (fallback: title).
    const text = (cur.message && cur.message.trim()) ? cur.message.trim() : (cur.title || "Reminder");
    await speak(text, settings.voice);
  }
}

async function clearNotificationsFor(remId) {
  try {
    const all = await chrome.notifications.getAll();
    for (const id of Object.keys(all || {})) {
      if (reminderIdFromNotification(id) === remId) await chrome.notifications.clear(id);
    }
  } catch (e) {}
}

function markCompleted(remId) {
  return runMutation(async () => {
    const { reminders } = await readState();
    const rem = reminders.find((r) => r.id === remId);
    if (!rem) return;
    rem.lastCompletedDate = WR.todayKey();
    rem.snoozedUntil = 0;
    rem.dndDeferred = false;
    if (rem.repeat === "once") { rem.completed = true; rem.enabled = false; }
    const idx = reminders.indexOf(rem);
    reminders[idx] = rem;
    await writeReminders(reminders);
    await chrome.alarms.clear(ALARM_PREFIX + rem.id);
    if (rem.repeat !== "once") await scheduleReminder(rem);
    await clearNotificationsFor(rem.id);
  });
}

function snoozeReminder(remId, minutes) {
  return runMutation(async () => {
    const { reminders } = await readState();
    const rem = reminders.find((r) => r.id === remId);
    if (!rem) return;
    const mins = Math.max(1, Math.min(1440, Math.round(+minutes || 5)));
    rem.snoozedUntil = Date.now() + mins * 60000;
    rem.dndDeferred = false;
    // A one-off switches itself off the moment it fires; snoozing it from the
    // notification must switch it back on for the snooze alarm to be honored.
    if (rem.repeat === "once") rem.enabled = true;
    const idx = reminders.indexOf(rem);
    reminders[idx] = rem;
    await writeReminders(reminders);
    await chrome.alarms.clear(ALARM_PREFIX + rem.id);
    await chrome.alarms.create(ALARM_PREFIX + rem.id, { when: rem.snoozedUntil });
    await clearNotificationsFor(rem.id);
  });
}

/* ---------------- screen time ----------------
   Approximate the time the browser is actively in use today. Each minute the
   tick checks whether the user is idle (chrome.idle); if active, the elapsed
   time since the previous tick is added to today's total. Long gaps (browser
   closed / slept) are not counted, so the figure stays honest. */
async function trackScreenTime() {
  try {
    const now = Date.now();
    const key = WR.todayKey(new Date(now));
    const got = await new Promise((r) => {
      chrome.storage.local.get(["screen"], (it) => r(it || {}));
    });
    const raw = got.screen && got.screen.day === key ? got.screen : { day: key, ms: 0, last: 0 };
    const s = WR.normalizeScreen(raw);
    let active = true;
    try {
      if (chrome.idle && chrome.idle.queryState) {
        active = await new Promise((r) => chrome.idle.queryState(90, (st) => r(st === "active")));
      }
    } catch (e) { active = true; }
    const delta = s.last ? now - s.last : 0;
    if (delta > 0 && delta <= 150000 && active) s.ms += delta; // skip gaps where the worker wasn't running
    s.ms = Math.min(24 * 60 * 60 * 1000, s.ms);
    s.last = now;
    await new Promise((resolve) => chrome.storage.local.set({ screen: s }, resolve));
  } catch (e) { /* screen time is best-effort */ }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm || !alarm.name) return;
  try {
    if (alarm.name === TICK) {
      await trackScreenTime();
      await updateActionClock();
      return await tickCheck();
    }
    if (alarm.name === UPDATE_CHECK_ALARM) return await checkForUpdates(false);
    if (alarm.name.indexOf(ALARM_PREFIX) !== 0) return;
    const id = alarm.name.slice(ALARM_PREFIX.length);
    const { reminders } = await readState();
    const rem = reminders.find((r) => r.id === id);
    if (!rem || rem.enabled === false) return;
    // Laptop asleep for hours? Chrome fires overdue alarms all at once on wake.
    // Don't blast a stale recurring alert — silently move it to the next slot.
    // One-offs and explicit snoozes still play, because the user asked for them.
    const scheduled = +alarm.scheduledTime || 0;
    const late = scheduled ? Date.now() - scheduled : 0;
    const isSnooze = !!(rem.snoozedUntil && Math.abs(scheduled - rem.snoozedUntil) < 5000);
    if (rem.repeat !== "once" && !isSnooze && late > 15 * 60000) {
      await scheduleReminder(rem);
      return;
    }
    await fireReminder(rem, { scheduled });
  } catch (e) {
    try { console.warn("Work Reminder: alarm failed", e && e.message); } catch (e2) {}
  }
});

/* Safety-net tick (every minute): fire any reminder whose time arrived but
   which never fired (alarm lost, worker restarted late, missed edge case). */
const TICK = "wr-tick";
async function ensureTick() {
  try {
    const all = await chrome.alarms.getAll();
    if (!all.some((a) => a.name === TICK)) {
      await chrome.alarms.create(TICK, { periodInMinutes: 1 });
    }
  } catch (e) {}
}

async function tickCheck() {
  const { reminders, settings } = await readState();
  if (!settings.enabled) return;
  const now = new Date();
  const nowMs = now.getTime();
  const startOfDay = new Date(now); startOfDay.setHours(0, 0, 0, 0);
  let existing = [];
  try { existing = await chrome.alarms.getAll(); } catch (e) {}
  const alarmByName = new Map(existing.map((a) => [a.name, a]));
  const haveAlarm = new Set(alarmByName.keys());
  for (const rem of reminders) {
    try {
      if (rem.enabled === false) continue;
      const name = ALARM_PREFIX + rem.id;

      // A pending snooze (or a one-off deferred by Do Not Disturb) is the
      // authoritative next occurrence. Restore a lost or stale alarm instead
      // of skipping the reminder because its original clock time passed.
      if (rem.snoozedUntil) {
        const sn = +rem.snoozedUntil;
        if (sn > nowMs) {
          const a = alarmByName.get(name);
          if (!a || Math.abs((a.scheduledTime || 0) - sn) > 5000) await scheduleReminder(rem);
          continue;
        }
        if (!rem.lastFiredAt || rem.lastFiredAt < sn) {
          await fireReminder(rem);
          continue;
        }
      }

      if (!WR.isActiveDay(rem, now)) continue;
      if (rem.lastCompletedDate === WR.todayKey(now)) continue;
      if (rem.repeat === "once" && rem.completed) continue;
      const firedToday = !!(rem.lastFiredAt && rem.lastFiredAt >= startOfDay.getTime());
      // A spent one-off stays quiet for the rest of today.
      if (rem.repeat === "once" && firedToday) continue;

      // A quick one-off has an exact at-time; other reminders use their clock
      // time. Using at avoids firing up to 59 seconds before the user asked.
      const dueMs = (rem.repeat === "once" && rem.at)
        ? +rem.at
        : (() => { const d = new Date(now); d.setHours(0, 0, 0, 0); d.setMinutes(WR.toMinutes(rem.time)); return d.getTime(); })();
      const diff = nowMs - dueMs;
      // Due within the last 10 minutes and not yet fired today -> fire it.
      if (!firedToday && diff >= 0 && diff < 10 * 60 * 1000) {
        await fireReminder(rem);
        continue;
      }
      // Self-heal: any missing alarm is restored, regardless of why it went away.
      if (!haveAlarm.has(name)) await scheduleReminder(rem);
    } catch (e) { /* never let one reminder break the tick */ }
  }
}

function openUpdateUrl(url) {
  try {
    const target = safeUpdateUrl(url) ? url : REPO_URL;
    const p = chrome.tabs.create({ url: target });
    if (p && typeof p.catch === "function") p.catch(() => {});
  } catch (e) {}
}

chrome.notifications.onButtonClicked.addListener(async (notifId, btn) => {
  try {
    try { await chrome.notifications.clear(notifId); } catch (e) {}
    if (notifId === UPDATE_NOTIF_ID) {
      if (btn === 0) {
        const { pendingUpdate } = await readState();
        openUpdateUrl((pendingUpdate && pendingUpdate.url) || REPO_URL);
      }
      return;
    }
    const remId = reminderIdFromNotification(notifId);
    if (!remId) return;
    const { settings } = await readState();
    if (btn === 0) await markCompleted(remId);
    else if (btn === 1) await snoozeReminder(remId, settings.defaultSnooze || 5);
  } catch (e) {
    try { console.warn("Work Reminder: notification button failed", e && e.message); } catch (e2) {}
  }
});

chrome.notifications.onClicked.addListener(async (notifId) => {
  try {
    try { await chrome.notifications.clear(notifId); } catch (e) {}
    if (notifId === UPDATE_NOTIF_ID) {
      const { pendingUpdate } = await readState();
      openUpdateUrl((pendingUpdate && pendingUpdate.url) || REPO_URL);
    }
  } catch (e) {
    try { console.warn("Work Reminder: notification click failed", e && e.message); } catch (e2) {}
  }
});

/* ---------------- default schedule ---------------- */

function defaultReminders() {
  const mk = (time, title, category, message) => ({
    id: WR.uid(), title, message, time,
    repeat: "daily", days: [0, 1, 2, 3, 4, 5, 6], category,
    voiceEnabled: true, notificationEnabled: true, sound: "default",
    enabled: true, completed: false, lastCompletedDate: null, lastFiredAt: null,
    createdAt: Date.now(), updatedAt: Date.now(),
  });
  return [
    mk("08:10", "Check In — Rigo App", "work", "Please remember to check in on the Rigo App."),
    mk("09:30", "Snack Break", "break", "It's time for a snack break."),
    mk("11:55", "Return Cup", "personal", "Please don't forget to take your cup to the kitchen floor."),
    mk("12:00", "Lunch Time — Stop Tracking", "break", "It's lunchtime. Please remember to stop your time tracking."),
    mk("17:00", "Check Out — Rigo App", "work", "Please remember to check out on the Rigo App. Your office hours for today are now over."),
  ];
}

const SEED_VERSION = 2;
// Title|time pairs of the previous (v1) default set — used to detect untouched installs.
const V1_DEFAULT_KEYS = new Set([
  "Start Work|10:00",
  "Return Cup|11:55",
  "Lunch Break|13:00",
  "Continue Development|14:00",
  "Drink Water|16:30",
  "Review Tasks|17:30",
  "Finish Work|18:00",
]);

let seedingPromise = null;
function seedIfNeeded() {
  // onInstalled and the worker boot can race on first install; share one seed.
  if (!seedingPromise) {
    seedingPromise = runMutation(seedIfNeededInner).finally(() => { seedingPromise = null; });
  }
  return seedingPromise;
}

async function seedIfNeededInner() {
  const state = await readState();
  if (!state.seeded) {
    // Never overwrite an existing schedule just because the seeded flag was
    // lost. Mark it seeded and leave the user's reminders alone.
    if (state.reminders.length) {
      await writeState({ seeded: true, seedVersion: SEED_VERSION });
      return;
    }
    await writeState({ reminders: defaultReminders().map((r) => WR.normalizeReminder(r)), seeded: true, seedVersion: SEED_VERSION });
    return;
  }
  if ((state.seedVersion || 1) < SEED_VERSION) {
    // One-time upgrade to the new default set.
    const current = state.reminders || [];
    if (current.length === 0) {
      // An intentionally emptied schedule must stay empty.
      await writeState({ seedVersion: SEED_VERSION });
      return;
    }
    const untouched = current.every((r) => V1_DEFAULT_KEYS.has(r.title + "|" + r.time));
    if (untouched) {
      // User never customized: replace wholesale with the new defaults.
      await writeState({ reminders: defaultReminders().map((r) => WR.normalizeReminder(r)), seedVersion: SEED_VERSION });
    } else {
      // User has custom reminders: only add any missing new defaults (matched by time).
      const haveTimes = new Set(current.map((r) => r.time));
      const missing = defaultReminders().filter((r) => !haveTimes.has(r.time));
      if (missing.length) await writeReminders(current.concat(missing));
      await writeState({ seedVersion: SEED_VERSION });
    }
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    await seedIfNeeded();
    await rebuildAlarms();
    await updateActionClock();
    await checkInstalledUpdate();
    await maybeAutoCheckUpdates();
  } catch (e) {
    try { console.warn("Work Reminder: install hook failed", e && e.message); } catch (e2) {}
  }
});

chrome.runtime.onStartup.addListener(async () => {
  try {
    await seedIfNeeded();
    await rebuildAlarms();
    await updateActionClock();
    await maybeAutoCheckUpdates();
  } catch (e) {
    try { console.warn("Work Reminder: startup hook failed", e && e.message); } catch (e2) {}
  }
});

/* Automatic update check: at most once every 6 hours, and only on a real
   browser start / install (not on every worker wake-up). A failed attempt is
   also throttled so an offline machine never hammers the API. */
const AUTO_UPDATE_MIN_MS = 6 * 60 * 60 * 1000;
async function maybeAutoCheckUpdates() {
  try {
    const { updateCheckedAt, updateAttemptedAt } = await readState();
    const last = Math.max(+updateCheckedAt || 0, +updateAttemptedAt || 0);
    if (last && Date.now() - last < AUTO_UPDATE_MIN_MS) return;
    await writeState({ updateAttemptedAt: Date.now() });
    await checkForUpdates(false);
  } catch (e) { /* updates are best-effort */ }
}

// Service worker wake-ups: keep alarms fresh.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== "background") return false;
  let replied = false;
  const reply = (value) => {
    if (replied) return;
    replied = true;
    try { sendResponse(value); } catch (e) {}
  };
  (async () => {
    try {
      switch (msg.action) {
        case "getState": {
          // A popup opened during first install must not briefly show an empty
          // schedule before the default seed lands.
          await seedIfNeeded();
          const fullState = await readState();
          const upd = fullState.pendingUpdate && compareVersions(chrome.runtime.getManifest().version, fullState.pendingUpdate.version) < 0
            ? fullState.pendingUpdate : null;
          reply({
            reminders: fullState.reminders,
            settings: fullState.settings,
            office: fullState.office,
            currentVersion: chrome.runtime.getManifest().version,
            repoUrl: REPO_URL,
            pendingUpdate: upd,
            updateCheckedAt: fullState.updateCheckedAt || 0,
            screen: fullState.screen,
          });
          break;
        }
        case "checkUpdate": {
          const res = await checkForUpdates(true);
          reply(res || { ok: false, version: chrome.runtime.getManifest().version, error: "Update check failed" });
          break;
        }
        case "rebuild":
          await rebuildAlarms();
          reply({ ok: true });
          break;
        case "complete":
          await markCompleted(msg.id);
          reply({ ok: true });
          break;
        case "snooze": {
          const st = await readState();
          await snoozeReminder(msg.id, msg.minutes || st.settings.defaultSnooze || 5);
          reply({ ok: true });
          break;
        }
        case "toggle": {
          const result = await runMutation(async () => {
            const { reminders } = await readState();
            const r = reminders.find((x) => x.id === msg.id);
            if (!r) return { ok: false, error: "Reminder not found" };
            const on = !!msg.enabled;
            // Re-enabling a spent one-off arms it once more (in a minute)
            // instead of leaving it silently switched on with no future slot.
            if (on && r.enabled === false && r.repeat === "once" && (r.completed || r.lastFiredAt)) {
              const d = new Date(Date.now() + 60000);
              r.completed = false;
              r.lastFiredAt = null;
              r.lastCompletedDate = null;
              r.snoozedUntil = 0;
              r.dndDeferred = false;
              r.time = WR.fromMinutes(d.getHours() * 60 + d.getMinutes());
              r.at = d.getTime();
            }
            r.enabled = on;
            if (!on) r.dndDeferred = false;
            r.updatedAt = Date.now();
            await writeReminders(reminders);
            await scheduleReminder(r);
            return { ok: true };
          });
          reply(result);
          break;
        }
        case "delete": {
          const result = await runMutation(async () => {
            const { reminders } = await readState();
            const before = reminders.length;
            const next = reminders.filter((x) => x.id !== msg.id);
            if (next.length === before) return { ok: false, error: "Reminder not found" };
            await writeReminders(next);
            await chrome.alarms.clear(ALARM_PREFIX + msg.id);
            await clearNotificationsFor(msg.id);
            return { ok: true };
          });
          reply(result);
          break;
        }
        case "save": {
          const result = await runMutation(async () => {
            const { reminders } = await readState();
            const incoming = WR.normalizeReminder(msg.reminder, WR.uid());
            if (!incoming.title) return { ok: false, error: "Please enter a title." };
            const i = reminders.findIndex((x) => x.id === incoming.id);
            if (i >= 0) {
              const prev = reminders[i];
              incoming.createdAt = prev.createdAt || incoming.createdAt;
              const scheduleChanged = incoming.time !== prev.time ||
                incoming.repeat !== prev.repeat ||
                (incoming.days || []).join(",") !== (prev.days || []).join(",");
              if (scheduleChanged) {
                // A moved reminder is a fresh occurrence, not one already handled.
                incoming.completed = false;
                incoming.lastCompletedDate = null;
                incoming.lastFiredAt = null;
                incoming.snoozedUntil = 0;
                incoming.dndDeferred = false;
              } else {
                // The edit form only contains schedule/content fields. Preserve
                // runtime state so renaming a reminder never loses its Done
                // check, cancels an active snooze or makes the tick fire twice.
                incoming.completed = !!prev.completed;
                incoming.lastCompletedDate = prev.lastCompletedDate || null;
                incoming.lastFiredAt = prev.lastFiredAt || null;
                incoming.snoozedUntil = prev.snoozedUntil || 0;
                incoming.dndDeferred = !!prev.dndDeferred;
              }
              // Editing must not silently switch a disabled reminder back on.
              incoming.enabled = prev.enabled !== false;
              // ...but a spent one-off that is edited is clearly being reused.
              const spentOnce = prev.repeat === "once" &&
                (prev.completed || (prev.enabled === false && !!prev.lastFiredAt));
              if (spentOnce) {
                incoming.completed = false;
                incoming.lastCompletedDate = null;
                incoming.lastFiredAt = null;
                incoming.snoozedUntil = 0;
                incoming.dndDeferred = false;
                incoming.enabled = true;
              }
              incoming.updatedAt = Date.now();
              reminders[i] = incoming;
            } else {
              incoming.completed = false;
              incoming.lastCompletedDate = null;
              incoming.lastFiredAt = null;
              incoming.snoozedUntil = 0;
              incoming.dndDeferred = false;
              incoming.enabled = true;
              incoming.updatedAt = Date.now();
              reminders.push(incoming);
            }
            await writeReminders(reminders);
            await scheduleReminder(incoming);
            return { ok: true, id: incoming.id };
          });
          reply(result);
          break;
        }
        case "saveSettings": {
          const result = await runMutation(async () => {
            const { settings } = await readState();
            const patch = (msg.settings && typeof msg.settings === "object") ? msg.settings : {};
            const merged = Object.assign({}, settings, patch);
            if (patch.voice && typeof patch.voice === "object") {
              merged.voice = Object.assign({}, settings.voice, patch.voice);
            }
            if (patch.sound && typeof patch.sound === "object") {
              merged.sound = Object.assign({}, settings.sound, patch.sound);
            }
            const clean = WR.normalizeSettings(merged);
            await writeState({ settings: clean });
            return { ok: true, settings: clean };
          });
          // Alarm and icon work is intentionally outside the lock, but both
          // re-read the latest state, so concurrent saves cannot undo each other.
          try { await syncAlarms(); } catch (e) {}
          try { await updateActionClock(); } catch (e) {}
          reply(result);
          break;
        }
        case "saveOffice": {
          const result = await runMutation(async () => {
            const { office } = await readState();
            const clean = WR.normalizeOffice(Object.assign({}, office, msg.office || {}));
            await writeState({ office: clean });
            return { ok: true, office: clean };
          });
          reply(result);
          break;
        }
        case "testVoice": {
          const { settings } = await readState();
          const cfg = Object.assign({}, settings.voice, msg.voice || {});
          const res = await speak(msg.text || "Please return your cup to the kitchen.", cfg);
          reply(res);
          break;
        }
        case "testSound": {
          const { settings } = await readState();
          const vol = isFinite(+msg.volume) ? +msg.volume : settings.sound.volume;
          await playSound(msg.name || settings.sound.name, vol);
          reply({ ok: true });
          break;
        }
        case "stopVoice":
          await stopAllAudio();
          reply({ ok: true });
          break;
        case "triggerNow": {
          const { reminders } = await readState();
          const r = reminders.find((x) => x.id === msg.id);
          if (!r) { reply({ ok: false, error: "Reminder not found" }); break; }
          await fireReminder(r, { force: true });
          reply({ ok: true });
          break;
        }
        case "addMany": {
          const result = await runMutation(async () => {
            const { reminders } = await readState();
            const existing = new Set(reminders.map((r) => r.title + "|" + r.time));
            const added = [];
            const rawList = Array.isArray(msg.reminders) ? msg.reminders.slice(0, 500) : [];
            for (const raw of rawList) {
              const r = WR.normalizeReminder(raw, WR.uid());
              const key = r.title + "|" + r.time;
              if (existing.has(key)) continue;
              existing.add(key);
              r.enabled = true;
              r.completed = false;
              r.lastCompletedDate = null;
              r.lastFiredAt = null;
              r.snoozedUntil = 0;
              r.dndDeferred = false;
              r.createdAt = Date.now();
              r.updatedAt = Date.now();
              reminders.push(r);
              added.push(r);
            }
            if (added.length) await writeReminders(reminders);
            for (const r of added) await scheduleReminder(r);
            return { ok: true, added: added.length };
          });
          reply(result);
          break;
        }
        case "quickAdd": {
          const result = await runMutation(async () => {
            const { reminders, settings } = await readState();
            const minutes = Math.max(1, Math.min(1440, Math.round(+msg.minutes || 10)));
            const at = Date.now() + minutes * 60000;
            const d = new Date(at);
            const label = String(msg.title || "").replace(/\s+/g, " ").trim();
            const rem = WR.normalizeReminder({
              id: WR.uid(),
              title: label || "Quick reminder",
              message: label || "Quick reminder.",
              time: WR.fromMinutes(d.getHours() * 60 + d.getMinutes()),
              at,
              repeat: "once",
              days: [],
              category: "custom",
              sound: msg.sound || (settings.sound && settings.sound.name) || "default",
              voiceEnabled: true,
              notificationEnabled: true,
              enabled: true,
              completed: false,
              lastCompletedDate: null,
              lastFiredAt: null,
            });
            reminders.push(rem);
            await writeReminders(reminders);
            await scheduleReminder(rem);
            return { ok: true, id: rem.id, at, time: rem.time };
          });
          reply(result);
          break;
        }
        case "pause": {
          const until = Math.max(0, +msg.until || 0);
          await runMutation(async () => {
            const { reminders, settings } = await readState();
            const next = Object.assign({}, settings, { pausedUntil: until });
            await writeState({ settings: WR.normalizeSettings(next) });
            // Resuming early releases one-offs that were deferred by DND.
            // A marker is used so a manual snooze is never mistaken for one.
            if (!until || until <= Date.now()) {
              let changed = false;
              for (const r of reminders) {
                if (r.dndDeferred) {
                  r.dndDeferred = false;
                  if (r.enabled !== false) {
                    r.snoozedUntil = r.repeat === "once" ? Date.now() + 1000 : 0;
                    changed = true;
                  }
                }
              }
              if (changed) {
                await writeReminders(reminders);
                for (const r of reminders) {
                  if (r.enabled !== false) await scheduleReminder(r);
                }
              }
            }
            return true;
          });
          // Silence anything already in progress when pausing.
          if (until > Date.now()) await stopAllAudio();
          reply({ ok: true, pausedUntil: until });
          break;
        }
        case "restore": {
          const result = await runMutation(async () => {
            const { reminders: current, settings, office } = await readState();
            const data = (msg.data && typeof msg.data === "object") ? msg.data : {};
            let count = current.length;
            if (Array.isArray(data.reminders)) {
              const clean = await writeReminders(data.reminders.slice(0, 1000));
              count = clean.length;
            }
            if (data.settings && typeof data.settings === "object") {
              const merged = Object.assign({}, settings, data.settings);
              if (data.settings.voice && typeof data.settings.voice === "object") {
                merged.voice = Object.assign({}, settings.voice, data.settings.voice);
              }
              if (data.settings.sound && typeof data.settings.sound === "object") {
                merged.sound = Object.assign({}, settings.sound, data.settings.sound);
              }
              const clean = WR.normalizeSettings(merged);
              clean.pausedUntil = 0; // an old backup must never silence this install
              clean.enabled = true;  // there is no visible "disabled globally" control
              await writeState({ settings: clean });
            }
            if (data.office && typeof data.office === "object") {
              await writeState({ office: WR.normalizeOffice(Object.assign({}, office, data.office)) });
            }
            return { ok: true, reminders: count };
          });
          try { await rebuildAlarms(); } catch (e) {}
          try { await updateActionClock(); } catch (e) {}
          reply(result);
          break;
        }
        default:
          reply({ ok: false, error: "Unknown action" });
      }
    } catch (e) {
      try { console.warn("Work Reminder: message failed", e && e.message); } catch (e2) {}
      reply({ ok: false, error: (e && e.message) || "Background error" });
    }
  })();
  return true;
});

// Worker boot: seed/migrate defaults, reconcile alarms (without destroying a
// live snooze), then refresh the clock/icon and confirm a just-installed update.
seedIfNeeded()
  .then(() => syncAlarms())
  .then(() => trackScreenTime())
  .then(() => updateActionClock())
  .then(() => checkInstalledUpdate())
  .catch(() => ensureTick());
ensureTick();
