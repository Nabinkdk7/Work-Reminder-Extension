(function () {
  "use strict";
  const WR = window.WR;
  const $ = (id) => document.getElementById(id);
  const ic = (name, cls) => '<svg class="ic' + (cls ? " " + cls : "") + '" aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
  const catIcons = { work: "briefcase", break: "coffee", meeting: "calendar", personal: "droplet", custom: "star" };

  let state = { reminders: [], settings: WR.DEFAULT_SETTINGS, office: WR.DEFAULT_OFFICE };
  let categoryFilter = null;
  let remFilter = "";

  function send(action, payload) {
    return new Promise((resolve) => {
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      };
      // Never leave the UI stuck if the worker is slow or the extension was
      // reloaded while this popup was open (context invalidated).
      const timer = setTimeout(() => finish(null), 20000);
      try {
        chrome.runtime.sendMessage(Object.assign({ target: "background", action }, payload || {}), (resp) => {
          if (chrome.runtime.lastError) return finish(null);
          finish(resp);
        });
      } catch (e) {
        finish(null);
      }
    });
  }

  async function refresh(opts) {
    const s = await send("getState");
    if (s) state = s;
    applyTheme();
    if (opts && opts.live) {
      // Periodic tick: only refresh what actually changes with time. Rebuilding
      // the lists every 30s used to destroy hover/focus under the cursor.
      renderNext(); renderToday($("todayList")); renderToday($("scheduleToday")); renderPause(); renderUpdate();
    } else {
      renderAll();
    }
  }

  function applyTheme() {
    let t = state.settings.theme;
    if (t === "system") t = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    document.body.dataset.theme = t;
  }
  try {
    const scheme = window.matchMedia("(prefers-color-scheme: light)");
    const onScheme = () => { if (state.settings && state.settings.theme === "system") applyTheme(); };
    if (scheme.addEventListener) scheme.addEventListener("change", onScheme);
    else if (scheme.addListener) scheme.addListener(onScheme);
  } catch (e) {}

  /* ---------- rendering ---------- */

  const DEV_URL = "https://nabinkhadka.com";

  function openExternal(url) {
    if (!/^https?:\/\//i.test(url || "")) return;
    try {
      const p = chrome.tabs.create({ url });
      if (p && typeof p.catch === "function") p.catch(() => window.open(url, "_blank"));
    } catch (e) {
      window.open(url, "_blank");
    }
  }

  function renderAll() {
    renderNext(); renderQuick(); renderClock(); renderStopwatch(); renderLapList();
    renderCategories(); renderToday($("todayList")); renderSchedulePage();
    renderReminderList(); renderSettings(); renderOffice(); renderPause(); renderUpdate();
  }

  function upcomingSorted() {
    const now = new Date();
    return state.reminders
      .filter((r) => r.enabled !== false)
      .map((r) => ({ r, next: WR.nextOccurrence(r, now) }))
      .filter((x) => x.next)
      .sort((a, b) => a.next - b.next);
  }

  function renderNext() {
    const up = upcomingSorted();
    if (!up.length) {
      $("nextTime").textContent = "--:--";
      $("nextCountdown").textContent = "";
      $("nextTitle").textContent = "No upcoming reminders";
      $("nextMessage").textContent = "Add one from the Reminders tab.";
      $("nextFlags").textContent = "";
      $("nextWhen").textContent = "—";
      $("nextDot").style.background = "transparent";
      $("nextDot").style.removeProperty("--dot");
      return;
    }
    const { r, next } = up[0];
    const snoozed = !!(r.snoozedUntil && r.snoozedUntil > Date.now());
    const mins = next.getHours() * 60 + next.getMinutes();
    $("nextTime").textContent = WR.formatTime(WR.fromMinutes(mins), state.settings.hourFormat);
    $("nextCountdown").textContent = (snoozed ? "snoozed · " : "") + "in " + WR.humanizeDuration(next.getTime() - Date.now());
    $("nextTitle").textContent = r.title;
    $("nextMessage").textContent = r.message || "";
    $("nextWhen").innerHTML = WR.todayKey(next) === WR.todayKey() ? ic("clock", "sm") + " Today" : ic("calendar", "sm") + " " + next.toLocaleDateString();
    const cat = WR.CATEGORY_MAP[r.category] || WR.CATEGORY_MAP.custom;
    $("nextDot").style.background = cat.color;
    $("nextDot").style.setProperty("--dot", cat.color);
    if (WR.isPaused(state.settings)) { $("nextFlags").innerHTML = ic("pause", "sm") + " Paused — reminders are silenced"; return; }
    const flags = [];
    if (state.settings.notificationsEnabled && r.notificationEnabled !== false) flags.push(ic("bell", "sm") + " Notification");
    if (state.settings.voiceEnabled && r.voiceEnabled !== false) flags.push(ic("volume", "sm") + " Voice");
    $("nextFlags").innerHTML = flags.length ? flags.join('<span class="flag-sep">•</span>') : (ic("bell-off", "sm") + " Silent");
  }

  /* ---------- quick reminder ---------- */

  const QUICK_MINUTES = [5, 10, 15, 30, 60];
  let quickMinutes = 10;

  function renderQuick() {
    const box = $("quickChips");
    if (!box || box.childElementCount === 0) {
      for (const m of QUICK_MINUTES) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "quick-chip";
        b.dataset.min = String(m);
        b.textContent = m + " min";
        b.addEventListener("click", () => { quickMinutes = m; renderQuick(); });
        box.appendChild(b);
      }
    }
    box.querySelectorAll(".quick-chip").forEach((c) => c.classList.toggle("on", +c.dataset.min === quickMinutes));
  }

  async function addQuick() {
    const title = $("quickText").value.trim();
    const res = await send("quickAdd", { minutes: quickMinutes, title });
    if (res && res.ok) {
      $("quickStatus").textContent = "Set for " + WR.formatTime(res.time, state.settings.hourFormat) + " (in " + quickMinutes + " min).";
      $("quickText").value = "";
      refresh();
    } else {
      $("quickStatus").textContent = "Could not set the quick reminder.";
    }
  }

  /* ---------- time & focus (clock, screen time, stopwatch) ---------- */

  function clockZoneText() {
    const off = -new Date().getTimezoneOffset();
    const sign = off >= 0 ? "+" : "-";
    const h = Math.floor(Math.abs(off) / 60), m = Math.abs(off) % 60;
    return "GMT" + sign + h + (m ? ":" + WR.pad(m) : "");
  }

  function screenMsLive() {
    const s = state.screen || {};
    if (s.day !== WR.todayKey()) return 0;
    let ms = +s.ms || 0;
    // While the popup is open the browser is active, so tick the figure forward.
    if (s.last) ms += Math.max(0, Math.min(150000, Date.now() - s.last));
    return ms;
  }

  function workdayInfo(now) {
    const o = state.office || {};
    const days = o.days || [];
    const s = WR.toMinutes(o.start), e = WR.toMinutes(o.end);
    if (e <= s) return null; // invalid range (e.g. a hand-edited backup)
    const nowM = now.getHours() * 60 + now.getMinutes();
    const isDay = days.includes(now.getDay());
    if (isDay && nowM >= s && nowM < e) return { label: "Workday ends in", ms: (e - nowM) * 60000 };
    if (isDay && nowM < s) return { label: "Workday starts in", ms: (s - nowM) * 60000 };
    for (let i = 1; i <= 7; i++) {
      const d = new Date(now); d.setDate(d.getDate() + i);
      if (!days.includes(d.getDay())) continue;
      const start = new Date(d); start.setHours(Math.floor(s / 60), s % 60, 0, 0);
      return { label: i === 1 ? "Workday starts tomorrow in" : "Next workday in", ms: start - now };
    }
    return null;
  }

  function renderClock() {
    const now = new Date();
    $("clockTime").textContent = now.toLocaleTimeString([], {
      hour: state.settings.hourFormat === 12 ? "numeric" : "2-digit",
      minute: "2-digit", second: "2-digit", hour12: state.settings.hourFormat === 12,
    });
    $("clockDate").textContent = now.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    const zone = clockZoneText();
    $("clockZone").textContent = zone;
    try { $("clockZone").title = Intl.DateTimeFormat().resolvedOptions().timeZone || zone; } catch (e) {}
    $("screenTime").textContent = WR.formatScreenTime(screenMsLive());
    const wd = workdayInfo(now);
    if (wd) { $("workdayLabel").textContent = wd.label; $("workdayLeft").textContent = WR.humanizeDuration(wd.ms); }
    else {
      $("workdayLabel").textContent = "Workday";
      $("workdayLeft").textContent = (state.office && state.office.days && state.office.days.length)
        ? "Set office hours" : "No office days set";
    }
  }

  let sw = { running: false, startedAt: 0, accumulated: 0, laps: [] };

  function loadStopwatch() {
    return new Promise((resolve) => {
      try { chrome.storage.local.get(["stopwatch"], (it) => { sw = Object.assign({ running: false, startedAt: 0, accumulated: 0, laps: [] }, (it && it.stopwatch) || {}); resolve(); }); }
      catch (e) { resolve(); }
    });
  }
  function saveStopwatch() { try { chrome.storage.local.set({ stopwatch: sw }); } catch (e) {} }
  function swElapsed() { return Math.max(0, (+sw.accumulated || 0) + (sw.running ? Date.now() - (+sw.startedAt || Date.now()) : 0)); }

  function renderStopwatch() {
    if (!$("swTime")) return;
    $("swTime").textContent = WR.formatStopwatch(swElapsed());
    const toggle = $("swToggle");
    toggle.textContent = sw.running ? "Pause" : (swElapsed() > 0 ? "Resume" : "Start");
    toggle.classList.toggle("running", !!sw.running);
    $("swLap").disabled = !(sw.running || swElapsed() > 0);
  }

  function renderLapList() {
    const ul = $("swLaps");
    if (!ul) return;
    const laps = sw.laps || [];
    if (!laps.length) { ul.innerHTML = ""; return; }
    ul.innerHTML = laps.map((ms, i) => {
      const prev = i > 0 ? laps[i - 1] : 0;
      return `<li><span>Lap ${i + 1}</span><b>${WR.formatStopwatch(ms - prev)}</b><span class="sw-total">${WR.formatStopwatch(ms)}</span></li>`;
    }).join("");
  }

  function onSwToggle() {
    if (sw.running) { sw.accumulated = swElapsed(); sw.running = false; sw.startedAt = 0; }
    else { sw.running = true; sw.startedAt = Date.now(); }
    saveStopwatch(); renderStopwatch();
  }
  function onSwLap() {
    if (!sw.running && !swElapsed()) return;
    sw.laps = [...(sw.laps || []), swElapsed()];
    saveStopwatch(); renderLapList();
  }
  function onSwReset() {
    sw = { running: false, startedAt: 0, accumulated: 0, laps: [] };
    saveStopwatch(); renderStopwatch(); renderLapList();
  }

  function renderCategories() {
    const grid = $("catGrid");
    grid.innerHTML = "";
    const up = upcomingSorted();
    for (const cat of WR.CATEGORIES.filter((c) => c.id !== "custom")) {
      const mine = state.reminders.filter((r) => (r.category || "custom") === cat.id && r.enabled !== false);
      const nextIn = up.find((x) => (x.r.category || "custom") === cat.id);
      const nextTime = nextIn
        ? WR.formatTime(WR.fromMinutes(nextIn.next.getHours() * 60 + nextIn.next.getMinutes()), state.settings.hourFormat)
        : "—";
      const el = document.createElement("div");
      el.className = "cat-card";
      el.style.setProperty("--cat", cat.color);
      el.innerHTML = `<div class="cat-ic">${ic(catIcons[cat.id] || "star")}</div><h4>${cat.label}</h4><p>${cat.desc}</p>
        <div class="meta"><span>Next: ${nextTime}</span><span class="count">${mine.length} ›</span></div>`;
      el.addEventListener("click", () => { categoryFilter = cat.id; switchView("reminders"); renderReminderList(); });
      grid.appendChild(el);
    }
  }

  function todayReminders() {
    const now = new Date();
    const key = WR.todayKey(now);
    return state.reminders
      .filter((r) => r.enabled !== false && WR.isActiveDay(r, now))
      // A one-off belongs to the day it will actually fire, so a one-off set
      // for a time that already passed (it fires tomorrow) is not shown as
      // "Missed" today.
      .filter((r) => {
        if (r.repeat !== "once") return true;
        const next = WR.nextOccurrence(r, now);
        return !!next && WR.todayKey(next) === key;
      })
      .sort((a, b) => WR.toMinutes(a.time) - WR.toMinutes(b.time));
  }

  function renderToday(listEl) {
    if (!listEl) return;
    const items = todayReminders();
    const sig = state.settings.hourFormat + "|" + items.map((r) =>
      [r.id, r.time, r.title, r.category, WR.todayStatus(r)].join("~")).join("|");
    if (listEl.dataset.sig === sig) return; // avoid rebuilding (and killing hover) needlessly
    listEl.dataset.sig = sig;
    listEl.innerHTML = "";
    const doneCount = items.filter((r) => WR.todayStatus(r) === "done").length;
    if ($("todayProgressBar")) {
      const pct = items.length ? Math.round((doneCount / items.length) * 100) : 0;
      $("todayProgressBar").style.width = pct + "%";
    }
    if (!items.length) { listEl.innerHTML = "<li><span class='grow muted'>No reminders today.</span></li>"; return; }
    for (const r of items) {
      const st = WR.todayStatus(r);
      const cat = WR.CATEGORY_MAP[r.category] || WR.CATEGORY_MAP.custom;
      const li = document.createElement("li");
      const chkClass = st === "done" ? "chk done" : st === "now" ? "chk now" : "chk";
      li.innerHTML = `<span class="${chkClass}">${st === "done" ? ic("check") : ""}</span>
        <span class="dot" style="background:${cat.color};--dot:${cat.color}"></span>
        <span class="t">${WR.formatTime(r.time, state.settings.hourFormat)}</span>
        <span class="grow">${escapeHtml(r.title)}</span>
        ${st === "done" ? '<span class="badge done">Done</span>' : ""}
        ${st === "now" ? '<span class="badge now">Now</span>' : ""}
        ${st === "missed" ? '<span class="badge missed">Missed</span>' : ""}`;
      li.style.cursor = "pointer";
      li.querySelector(".chk").addEventListener("click", (e) => {
        e.stopPropagation();
        if (WR.todayStatus(r) !== "done") send("complete", { id: r.id }).then(refresh);
      });
      li.addEventListener("click", () => openReminderDetail(r));
      listEl.appendChild(li);
    }
    $("todayCount").textContent = doneCount + "/" + items.length + " ›";
  }

  function renderReminderList() {
    const box = $("reminderList");
    box.innerHTML = "";
    let list = [...state.reminders].sort((a, b) => WR.toMinutes(a.time) - WR.toMinutes(b.time));
    if (categoryFilter) list = list.filter((r) => r.category === categoryFilter);
    if (remFilter) {
      const q = remFilter.toLowerCase();
      list = list.filter((r) => (r.title || "").toLowerCase().includes(q) || (r.message || "").toLowerCase().includes(q));
    }
    if (!list.length) {
      box.innerHTML = "<p class='muted'>" + (remFilter ? "No reminders match your search." : "No reminders. Click + Add to create one.") + "</p>";
    }
    for (const r of list) {
      const cat = WR.CATEGORY_MAP[r.category] || WR.CATEGORY_MAP.custom;
      const el = document.createElement("div");
      el.className = "rem-card";
      el.innerHTML = `<div class="time">${WR.formatTime(r.time, state.settings.hourFormat)}</div>
        <div class="info"><b>${escapeHtml(r.title)}</b><p>${repeatLabel(r)} • ${cat.label}${r.voiceEnabled !== false ? " • " + ic("volume", "sm") : ""}${r.snoozedUntil && r.snoozedUntil > Date.now() ? " • snoozed" : ""}${r.repeat === "once" && r.at ? " • " + ic("zap", "sm") + " quick" : ""}</p></div>
        <button class="mini-btn" data-act="dup" title="Duplicate">${ic("copy")}</button>
        <button class="mini-btn" data-act="edit" title="Edit">${ic("edit")}</button>
        <button class="mini-btn" data-act="del" title="Delete">${ic("trash")}</button>
        <label class="switch"><input type="checkbox" ${r.enabled !== false ? "checked" : ""}><span class="slider"></span></label>`;
      el.querySelector('[data-act="edit"]').addEventListener("click", () => openForm(r));
      el.querySelector('[data-act="dup"]').addEventListener("click", async () => {
        const copy = Object.assign({}, r, {
          completed: false,
          lastCompletedDate: null,
          lastFiredAt: null,
          snoozedUntil: 0,
          enabled: true,
          title: r.title + " (copy)",
          updatedAt: Date.now(),
        });
        delete copy.id;
        delete copy.at; // a copy is a fresh occurrence, never an instant replay
        await send("save", { reminder: copy });
        refresh();
      });
      el.querySelector('[data-act="del"]').addEventListener("click", () => openConfirm(r));
      el.querySelector("input").addEventListener("change", async (e) => { await send("toggle", { id: r.id, enabled: e.target.checked }); refresh(); });
      el.querySelector(".info").style.cursor = "pointer";
      el.querySelector(".info").addEventListener("click", () => openReminderDetail(r));
      box.appendChild(el);
    }
    if (categoryFilter) {
      const clear = document.createElement("button");
      clear.className = "btn"; clear.textContent = "Show all";
      clear.addEventListener("click", () => { categoryFilter = null; renderReminderList(); });
      box.prepend(clear);
    }
  }

  function openReminderDetail(r) {
    // Open the edit form as the detail view; the schedule list has a Done toggle.
    openForm(r);
  }

  function renderSchedulePage() {
    const o = state.office;
    $("officeHours").textContent = WR.formatTime(o.start, state.settings.hourFormat) + " – " + WR.formatTime(o.end, state.settings.hourFormat);
    $("officeLunch").textContent = WR.formatTime(o.lunchStart, state.settings.hourFormat) + " – " + WR.formatTime(o.lunchEnd, state.settings.hourFormat);
    $("officeDays").textContent = o.days.map((d) => WR.WEEKDAYS[d].slice(0, 3)).join(", ") || "None";
    renderToday($("scheduleToday"));
  }

  /* Selects must always show the stored value, even if it came from an older
     version or a restored backup (otherwise the control goes blank). */
  function setSelectValue(el, value) {
    if (!el) return;
    const v = String(value);
    if (!Array.from(el.options).some((o) => o.value === v)) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      el.appendChild(opt);
    }
    el.value = v;
  }

  function renderSettings() {
    const s = state.settings;
    setSelectValue($("setHourFormat"), s.hourFormat);
    setSelectValue($("setSnooze"), s.defaultSnooze);
    setSelectValue($("setTheme"), s.theme);
    $("setIconClock").checked = s.iconClock !== false;
    $("setNotif").checked = !!s.notificationsEnabled;
    setSelectValue($("setSound"), s.sound.name);
    $("setSoundVol").value = s.sound.volume;
    $("setVoice").checked = !!s.voiceEnabled;
    setSelectValue($("setLang"), s.voice.language);
    setSelectValue($("setGender"), s.voice.gender);
    setSelectValue($("setSpeed"), s.voice.speed);
    $("setVoiceVol").value = s.voice.volume;
    $("voiceToggle").innerHTML = ic(s.voiceEnabled ? "volume" : "volume-off");
  }

  function renderOffice() {
    const o = state.office;
    $("offStart").value = o.start; $("offEnd").value = o.end;
    $("offLunchStart").value = o.lunchStart; $("offLunchEnd").value = o.lunchEnd;
    buildDayChips($("offDays"), o.days, () => {});
  }

  /* ---------- do not disturb ---------- */

  let wasPaused = false;
  function renderPause() {
    const paused = WR.isPaused(state.settings);
    const until = +state.settings.pausedUntil || 0;
    $("pauseBanner").classList.toggle("hidden", !paused);
    $("pauseBtn").innerHTML = ic(paused ? "play" : "pause");
    $("pauseBtn").title = paused ? "Resume reminders" : "Pause reminders for 30 min";
    if (paused) {
      $("pauseBannerText").textContent = "Reminders paused — " + WR.humanizeDuration(until - Date.now()) + " left.";
      $("pauseStatus").textContent = "All reminders are paused until " + new Date(until).toLocaleString() + ".";
      $("dndHeadBadge").textContent = "Paused";
      // Expand once when a pause starts; respect the user closing it afterwards.
      if (dndToggle && !wasPaused) dndToggle.set(true, false);
    } else {
      $("pauseStatus").textContent = "Reminders are running normally.";
      $("dndHeadBadge").textContent = "Off";
    }
    wasPaused = paused;
  }

  function setPause(until) {
    return send("pause", { until }).then(() => refresh());
  }

  /* ---------- updates ---------- */

  let lastPendingVersion = null;
  function renderUpdate() {
    const current = state.currentVersion || (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || "—";
    $("updCurrent").textContent = "v" + current;
    $("updHeadVer").textContent = "v" + current;
    $("updChecked").textContent = state.updateCheckedAt
      ? new Date(state.updateCheckedAt).toLocaleString()
      : "Never";
    const p = state.pendingUpdate;
    if (p && p.version) {
      $("updPanel").classList.remove("hidden");
      $("updLatest").textContent = "v" + p.version;
      $("updNotes").textContent = p.notes || "";
      if (!$("updStatus").dataset.keep) $("updStatus").textContent = "A newer version is available below.";
    } else {
      $("updPanel").classList.add("hidden");
    }
    // Auto-expand once for a *new* pending version, then respect the user's choice.
    if (updToggle) {
      if (p && p.version) {
        if (p.version !== lastPendingVersion) updToggle.set(true, false);
        lastPendingVersion = p.version;
      } else {
        lastPendingVersion = null;
      }
    }
  }

  let checkingUpdate = false;
  async function onCheckUpdate() {
    if (checkingUpdate) return;
    checkingUpdate = true;
    $("updCheckBtn").disabled = true;
    $("updStatus").textContent = "Checking GitHub for updates…";
    try {
      const res = await send("checkUpdate", {});
      if (!res || !res.ok) {
        $("updStatus").textContent = "Could not reach the update server. Check your connection and try again.";
      } else if (res.update) {
        state.pendingUpdate = { version: res.latest, notes: res.notes, url: res.url };
        state.updateCheckedAt = res.checkedAt;
        $("updStatus").dataset.keep = "1";
        $("updStatus").textContent = "Update v" + res.latest + " available — a notification was also shown.";
        renderUpdate();
      } else {
        // Up to date: inline confirmation only, never a notification.
        state.pendingUpdate = null;
        state.updateCheckedAt = res.checkedAt;
        delete $("updStatus").dataset.keep;
        $("updStatus").textContent = "You're up to date (v" + res.current + ").";
        renderUpdate();
      }
    } catch (e) {
      $("updStatus").textContent = "Could not reach the update server. Check your connection and try again.";
    }
    $("updCheckBtn").disabled = false;
    checkingUpdate = false;
  }

  async function onVerifyFolder() {
    const statusEl = $("updFolderStatus");
    try {
      if (typeof window.showDirectoryPicker !== "function") {
        statusEl.textContent = "Folder picker isn't available in this browser. Compare versions manually instead.";
        return;
      }
      statusEl.textContent = "Select your extension folder…";
      const dir = await window.showDirectoryPicker({ mode: "read" });
      let manifestText = null;
      for await (const entry of dir.values()) {
        if (entry.kind === "file" && entry.name.toLowerCase() === "manifest.json") {
          manifestText = await (await entry.getFile()).text();
          break;
        }
      }
      if (!manifestText) {
        statusEl.textContent = "That folder doesn't look like the extension (no manifest.json found).";
        return;
      }
      const mf = JSON.parse(manifestText);
      if (mf.name !== "Work Reminder") {
        statusEl.textContent = "That folder is a different extension (" + (mf.name || "unknown") + ").";
        return;
      }
      const folderVer = mf.version || "?";
      const current = state.currentVersion || "";
      statusEl.textContent = "Folder \"" + dir.name + "\" holds Work Reminder v" + folderVer +
        (current && folderVer === current ? " — matches this install." : " (this install runs v" + current + "). Reload the extension after replacing its files.");
    } catch (e) {
      if (e && e.name === "AbortError") { statusEl.textContent = ""; return; }
      statusEl.textContent = "Could not read that folder. Make sure you selected the extracted extension folder.";
    }
  }

  /* ---------- collapsible sections (Updates + Do Not Disturb + Backup) ---------- */

  function makeCollapsible(opts) {
    const { head, body, chev, key, guard } = opts;
    let open = false;
    function apply(state) {
      open = !!state;
      $(body).classList.toggle("hidden", !open);
      $(chev).classList.toggle("open", open);
      $(head).setAttribute("aria-expanded", open ? "true" : "false");
      $(head).title = (open ? "Hide " : "Show ") + opts.label + " details";
    }
    function set(state, persist) {
      apply(state);
      if (persist !== false) {
        try {
          chrome.storage.local.get(["wrUi"], (items) => {
            const ui = (items && items.wrUi) || {};
            ui[key] = open;
            try { chrome.storage.local.set({ wrUi: ui }); } catch (e) {}
          });
        } catch (e) {}
      }
    }
    apply(open);
    const toggle = () => set(!open);
    $(head).addEventListener("click", toggle);
    $(head).addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); }
    });
    try {
      chrome.storage.local.get(["wrUi"], (items) => {
        if (guard && guard()) return; // e.g. a pending update must stay expanded
        if (items && items.wrUi && typeof items.wrUi[key] === "boolean") apply(items.wrUi[key]);
      });
    } catch (e) {}
    return { set, isOpen: () => open };
  }

  let updToggle = null;
  let dndToggle = null;
  let dataToggle = null;

  /* ---------- backup & restore ---------- */

  function onExport() {
    try {
      const data = {
        app: "Work Reminder",
        version: state.currentVersion || "",
        exportedAt: new Date().toISOString(),
        reminders: state.reminders,
        settings: state.settings,
        office: state.office,
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "work-reminder-backup-" + WR.todayKey() + ".json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      $("dataStatus").textContent = "Backup downloaded (" + state.reminders.length + " reminders).";
    } catch (e) {
      $("dataStatus").textContent = "Could not create the backup file.";
    }
  }

  async function onImportFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data || !Array.isArray(data.reminders)) {
        $("dataStatus").textContent = "That file isn't a Work Reminder backup.";
        return;
      }
      const res = await send("restore", { data });
      if (res && res.ok) {
        $("dataStatus").textContent = "Restored " + res.reminders + " reminders.";
        refresh();
      } else {
        $("dataStatus").textContent = "Could not restore that backup.";
      }
    } catch (err) {
      $("dataStatus").textContent = "That file could not be read.";
    } finally {
      e.target.value = "";
    }
  }

  /* ---------- day chips ---------- */
  const DAY_LETTERS = ["S", "M", "T", "W", "T", "F", "S"];
  function buildDayChips(container, selected, onChange) {
    container.innerHTML = "";
    for (let d = 0; d < 7; d++) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "chip" + (selected.includes(d) ? " on" : "");
      b.textContent = DAY_LETTERS[d]; b.title = WR.WEEKDAYS[d];
      b.addEventListener("click", () => {
        const i = selected.indexOf(d);
        if (i >= 0) selected.splice(i, 1); else selected.push(d);
        b.classList.toggle("on");
        onChange(selected);
      });
      container.appendChild(b);
    }
  }

  function repeatLabel(r) {
    if (r.repeat === "once") return r.at ? "One-off" : "Once";
    if (r.repeat === "daily") return "Every day";
    if (r.repeat === "weekdays") return "Weekdays";
    return "Custom days";
  }

  /* ---------- navigation ---------- */
  function switchView(name) {
    const target = document.getElementById("view-" + name);
    const changed = !target || !target.classList.contains("active");
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.view === name));
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + name));
    if (changed) {
      try {
        // The body is the scroll container in the popup shell.
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      } catch (e) {}
    }
  }
  document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => {
    const hadFilter = !!categoryFilter;
    categoryFilter = null;
    switchView(t.dataset.view);
    if (t.dataset.view === "reminders" && hadFilter) renderReminderList();
  }));
  $("settingsBtn").addEventListener("click", () => switchView("settings"));
  $("voiceToggle").addEventListener("click", async () => {
    const next = !state.settings.voiceEnabled;
    const res = await send("saveSettings", { settings: { voiceEnabled: next } });
    if (res && res.ok) {
      state.settings.voiceEnabled = next;
      renderSettings();
      renderNext();
    }
  });

  /* ---------- form ---------- */
  let formDays = [];
  function closeForm() {
    $("modal").classList.add("hidden");
    try { $("addReminderBtn").focus(); } catch (e) {}
  }
  function openForm(r) {
    $("modal").classList.remove("hidden");
    $("modalTitle").textContent = r ? "Edit Reminder" : "Add Reminder";
    $("fId").value = r ? r.id : "";
    $("fTime").value = r ? r.time : "11:55";
    $("fTitle").value = r ? r.title : "";
    $("fMessage").value = r ? r.message || "" : "";
    $("fCategory").value = r ? r.category : "work";
    $("fRepeat").value = r ? r.repeat : "daily";
    $("fSound").value = r && r.sound ? r.sound : "default";
    $("fVoice").checked = r ? r.voiceEnabled !== false : true;
    $("fNotif").checked = r ? r.notificationEnabled !== false : true;
    formDays = r && r.days ? [...r.days] : [1, 2, 3, 4, 5];
    buildDayChips($("fDays"), formDays, () => {});
    toggleDaysRow();
    const status = $("formStatus");
    status.textContent = "";
    status.hidden = true;
    setTimeout(() => { try { (r ? $("fTitle") : $("fTime")).focus(); } catch (e) {} }, 40);
  }
  function formError(message, focusEl) {
    const status = $("formStatus");
    status.textContent = message;
    status.hidden = false;
    if (focusEl) { try { focusEl.focus(); } catch (e) {} }
  }

  /* Delete confirmation lives in the popup: native confirm() can defocus a
     Chrome popup, which used to make deleting a reminder unreliable. */
  let pendingDelete = null;
  function openConfirm(r) {
    pendingDelete = r;
    $("confirmText").textContent = "\u201C" + r.title + "\u201D will be removed. This cannot be undone.";
    $("confirmModal").classList.remove("hidden");
    setTimeout(() => { try { $("confirmCancel").focus(); } catch (e) {} }, 40);
  }
  function closeConfirm() {
    $("confirmModal").classList.add("hidden");
    pendingDelete = null;
  }
  $("confirmCancel").addEventListener("click", closeConfirm);
  $("confirmModal").addEventListener("click", (e) => { if (e.target === $("confirmModal")) closeConfirm(); });
  $("confirmModal").addEventListener("keydown", (e) => {
    if (e.key !== "Tab") return;
    const focusables = Array.from($("confirmModal").querySelectorAll("button"))
      .filter((el) => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0], last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  $("confirmDelete").addEventListener("click", async () => {
    const r = pendingDelete;
    closeConfirm();
    if (r) { await send("delete", { id: r.id }); refresh(); }
  });
  function toggleDaysRow() {
    $("fDaysWrap").style.display = $("fRepeat").value === "custom" ? "flex" : "none";
  }
  $("fRepeat").addEventListener("change", toggleDaysRow);
  $("fCancel").addEventListener("click", closeForm);
  $("modal").addEventListener("click", (e) => { if (e.target === $("modal")) closeForm(); });
  $("modal").addEventListener("keydown", (e) => {
    if (e.key !== "Tab") return;
    const focusables = Array.from($("modal").querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))
      .filter((el) => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0], last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (!$("confirmModal").classList.contains("hidden")) { closeConfirm(); return; }
    if (!$("modal").classList.contains("hidden")) { closeForm(); return; }
    if (!$("suggestModal").classList.contains("hidden")) $("suggestModal").classList.add("hidden");
  });
  $("fPreviewSound").addEventListener("click", () => {
    const name = $("fSound").value;
    if (name && name !== "none") send("testSound", { name });
  });
  $("fSave").addEventListener("click", async () => {
    const title = $("fTitle").value.trim();
    if (!title) { formError("Please enter a title for this reminder.", $("fTitle")); return; }
    if ($("fRepeat").value === "custom" && !formDays.length) {
      formError("Pick at least one day for a custom repeat.", $("fRepeat"));
      return;
    }
    const existing = state.reminders.find((r) => r.id === $("fId").value) || {};
    const reminder = Object.assign({}, existing, {
      title,
      message: $("fMessage").value.trim(),
      time: $("fTime").value || "09:00",
      category: $("fCategory").value,
      repeat: $("fRepeat").value,
      days: $("fRepeat").value === "custom" ? formDays : $("fRepeat").value === "weekdays" ? [1, 2, 3, 4, 5] : $("fRepeat").value === "daily" ? [0, 1, 2, 3, 4, 5, 6] : [],
      sound: $("fSound").value,
      voiceEnabled: $("fVoice").checked,
      notificationEnabled: $("fNotif").checked,
      enabled: existing.enabled !== undefined ? existing.enabled : true,
    });
    delete reminder.at; // editing turns a quick one-off into a normal scheduled reminder
    await send("save", { reminder });
    closeForm();
    refresh();
  });
  $("addReminderBtn").addEventListener("click", () => openForm(null));

  /* ---------- settings save ---------- */
  function bindSettingSave() {
    let timer = 0;
    const save = async () => {
      clearTimeout(timer); timer = 0;
      // Send only the settings this view owns — never a stale copy of
      // pausedUntil or other state that the background may have changed.
      const patch = {
        hourFormat: +$("setHourFormat").value,
        defaultSnooze: +$("setSnooze").value,
        theme: $("setTheme").value,
        iconClock: $("setIconClock").checked,
        notificationsEnabled: $("setNotif").checked,
        sound: { name: $("setSound").value, volume: +$("setSoundVol").value },
        voiceEnabled: $("setVoice").checked,
        voice: {
          language: $("setLang").value,
          gender: $("setGender").value,
          speed: $("setSpeed").value,
          volume: +$("setVoiceVol").value,
        },
      };
      Object.assign(state.settings, patch);
      state.settings.sound = Object.assign({}, state.settings.sound, patch.sound);
      state.settings.voice = Object.assign({}, state.settings.voice, patch.voice);
      await send("saveSettings", { settings: patch });
      applyTheme(); renderNext(); renderToday($("todayList")); renderSettings();
    };
    const scheduleSave = (immediate) => {
      clearTimeout(timer);
      if (immediate) save();
      else timer = setTimeout(save, 220); // sliders: coalesce the drag into one write
    };
    $("view-settings").addEventListener("change", () => scheduleSave(true));
    $("view-settings").addEventListener("input", (e) => { if (e.target.type === "range") scheduleSave(false); });
  }
  bindSettingSave();

  $("testVoiceBtn").addEventListener("click", async () => {
    const up = upcomingSorted();
    const text = up.length && (up[0].r.message || "").trim()
      ? up[0].r.message.trim()
      : "Please return your cup to the kitchen.";
    const voice = {
      language: $("setLang").value,
      gender: $("setGender").value,
      speed: $("setSpeed").value,
      volume: +$("setVoiceVol").value,
    };
    // Use the values currently on screen, even if the debounced save hasn't run.
    const res = await send("testVoice", { text, voice });
    const el = $("voiceStatus");
    if (!el) return;
    el.hidden = false;
    if (!res) el.textContent = "Could not start the voice test.";
    else if (res.ok) el.textContent = "Playing with " + (res.voice || "the system voice") + ".";
    else if (res.error === "no-voice-for-gender") {
      el.textContent = "No " + (voice.gender === "male" ? "male" : "female") +
        " voice is installed — choose System or change the language.";
    } else if (res.error === "no-voices") {
      el.textContent = "No system voices are available.";
    } else {
      el.textContent = "Voice test failed (" + (res.error || "unknown error") + ").";
    }
  });
  $("testSoundBtn").addEventListener("click", () => {
    send("testSound", { name: $("setSound").value, volume: +$("setSoundVol").value });
  });

  /* ---------- quick reminder + pause bindings ---------- */
  $("quickAddBtn").addEventListener("click", addQuick);
  $("quickText").addEventListener("keydown", (e) => { if (e.key === "Enter") addQuick(); });
  $("pauseBtn").addEventListener("click", () => setPause(WR.isPaused(state.settings) ? 0 : Date.now() + 30 * 60000));
  $("resumeBtn").addEventListener("click", () => setPause(0));
  $("resumeBtn2").addEventListener("click", () => setPause(0));
  $("pause30Btn").addEventListener("click", () => setPause(Date.now() + 30 * 60000));
  $("pause60Btn").addEventListener("click", () => setPause(Date.now() + 60 * 60000));
  $("pauseTomorrowBtn").addEventListener("click", () => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(0, 0, 0, 0);
    setPause(d.getTime());
  });
  $("remSearch").addEventListener("input", (e) => { remFilter = e.target.value.trim(); renderReminderList(); });
  $("swToggle").addEventListener("click", onSwToggle);
  $("swLap").addEventListener("click", onSwLap);
  $("swReset").addEventListener("click", onSwReset);

  /* ---------- backup bindings ---------- */
  $("exportBtn").addEventListener("click", onExport);
  $("importBtn").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", onImportFile);

  /* ---------- updates + about ---------- */
  try {
    if (typeof window.showDirectoryPicker !== "function" && $("updFolderBtn")) {
      $("updFolderBtn").style.display = "none";
    }
  } catch (e) {}
  updToggle = makeCollapsible({
    head: "updHeadToggle", body: "updBody", chev: "updChevron", key: "updOpen", label: "update",
    guard: () => !!(state.pendingUpdate && state.pendingUpdate.version),
  });
  dndToggle = makeCollapsible({ head: "dndHeadToggle", body: "dndBody", chev: "dndChevron", key: "dndOpen", label: "Do Not Disturb" });
  dataToggle = makeCollapsible({ head: "dataHeadToggle", body: "dataBody", chev: "dataChevron", key: "dataOpen", label: "backup" });
  $("updCheckBtn").addEventListener("click", onCheckUpdate);
  $("updDownloadBtn").addEventListener("click", () => {
    const url = (state.pendingUpdate && state.pendingUpdate.url) || state.repoUrl;
    if (url) openExternal(url);
  });
  $("updFolderBtn").addEventListener("click", onVerifyFolder);
  $("repoLink").addEventListener("click", (e) => {
    e.preventDefault();
    if (state.repoUrl) openExternal(state.repoUrl);
  });
  $("devLink").addEventListener("click", (e) => { e.preventDefault(); openExternal(DEV_URL); });

  /* ---------- office ---------- */
  $("saveOfficeBtn").addEventListener("click", async () => {
    const statusEl = $("officeStatus");
    const start = $("offStart").value, end = $("offEnd").value;
    const lunchStart = $("offLunchStart").value, lunchEnd = $("offLunchEnd").value;
    const showOfficeError = (msg) => { statusEl.classList.add("error"); statusEl.textContent = msg; };
    if (!start || !end) { showOfficeError("Set both an office start and end time."); return; }
    if (WR.toMinutes(end) <= WR.toMinutes(start)) {
      showOfficeError("Office end time must be after the start time.");
      return;
    }
    if (lunchStart && lunchEnd && WR.toMinutes(lunchEnd) <= WR.toMinutes(lunchStart)) {
      showOfficeError("Lunch end time must be after lunch start.");
      return;
    }
    const sel = [];
    $("offDays").querySelectorAll(".chip").forEach((c, d) => { if (c.classList.contains("on")) sel.push(d); });
    await send("saveOffice", { office: { start, end, lunchStart, lunchEnd, days: sel } });
    await refresh();
    statusEl.classList.remove("error");
    statusEl.textContent = sel.length
      ? "Office hours saved."
      : "Office hours saved, but no working days are selected — the workday countdown will stay hidden.";
    setTimeout(() => { if (statusEl.textContent === "Office hours saved.") statusEl.textContent = ""; }, 4000);
  });

  /* ---------- smart schedule ---------- */
  $("suggestBtn").addEventListener("click", () => {
    const o = state.office;
    const add = (time, title, category, message) => ({
      title, message, time, category, repeat: "weekdays", days: o.days,
      voiceEnabled: true, notificationEnabled: true, sound: "default",
      enabled: true, repeat2: undefined,
    });
    const suggestions = [
      add(o.start, "Start Work", "work", "Start work. Have a productive day!"),
      add(WR.fromMinutes(WR.toMinutes(o.start) + 30), "Check Emails", "work", "Check your emails and plan the day."),
      add(WR.fromMinutes(WR.toMinutes(o.start) + 120), "Take a Break", "break", "Take a short break. Rest your eyes."),
      add(o.lunchStart, "Lunch Break", "break", "Time for lunch. Take a proper break!"),
      add(o.lunchEnd, "Continue Work", "work", "Back to work. Focus time!"),
      add(WR.fromMinutes((WR.toMinutes(o.lunchEnd) + WR.toMinutes(o.end)) / 2 | 0), "Drink Water", "personal", "Drink a glass of water."),
      add(WR.fromMinutes(WR.toMinutes(o.end) - 30), "Review Tasks", "work", "Review your tasks before wrapping up."),
      add(o.end, "Finish Work", "work", "Finish work. Great job today!"),
    ];
    const list = $("suggestList");
    list.innerHTML = "";
    for (const s of suggestions) {
      const li = document.createElement("li");
      li.innerHTML = `<span class="t">${WR.formatTime(s.time, state.settings.hourFormat)}</span><span class="grow">${s.title}</span>`;
      list.appendChild(li);
    }
    $("suggestAdd").onclick = async () => {
      const clean = suggestions.map((s) => { const { repeat2, ...rest } = s; return rest; });
      const res = await send("addMany", { reminders: clean });
      const added = res && res.added != null ? res.added : 0;
      $("suggestModal").classList.add("hidden");
      const status = $("scheduleStatus");
      if (status) {
        status.hidden = false;
        status.textContent = "Added " + added + " new reminder" + (added === 1 ? "" : "s") + ".";
      }
      refresh();
    };
    $("suggestCustomize").onclick = () => { $("suggestModal").classList.add("hidden"); switchView("reminders"); };
    $("suggestCancel").onclick = () => $("suggestModal").classList.add("hidden");
    $("suggestModal").classList.remove("hidden");
  });

  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  loadStopwatch().then(() => { renderStopwatch(); renderLapList(); });
  refresh();
  setInterval(() => { refresh({ live: true }); }, 30000);
  setInterval(() => { renderClock(); }, 1000);
  setInterval(() => { if (sw.running) renderStopwatch(); }, 100);
})();
