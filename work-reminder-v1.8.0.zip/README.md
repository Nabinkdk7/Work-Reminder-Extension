# Work Reminder

A premium personal workday reminder, alarm, schedule and voice notification browser extension (Manifest V3).

Dev by [Nabin Khadka](https://nabinkhadka.com) · [GitHub Repository](https://github.com/Nabinkdk7/Work-Reminder-Extension)

## Features

- **Liquid-glass dashboard** — frosted panels, soft aurora glows and cyan→violet gradients on a deep navy canvas, with a next-reminder hero card with a live **countdown**, colorful category cards (Work, Breaks, Meetings, Personal), Today's Schedule with a **progress bar** and Done/Now/Missed/Upcoming statuses.
- **Quick Reminder** — get a one-off nudge in 5/10/15/30/60 minutes without touching the schedule.
- **Do Not Disturb** — pause every reminder, sound and voice for 30 min, 1 hour or until tomorrow; a banner shows the time left.
- **Backup & Restore** — export all reminders and settings to a JSON file and restore them on another computer or after reinstalling.
- **Time & Focus card** — a live **local clock** (with timezone), **screen time today** (time the browser is actively in use, tracked with `chrome.idle`), a **workday countdown** to the end of your office hours, and a persistent **stopwatch** with lap times that keeps running even when the popup is closed.
- **Polished, high-quality sounds** — the WebAudio synth runs through a peak limiter with warm harmonics, a sub-octave body and subtle stereo width, so every alert is full and clear instead of thin or harsh.
- **Subtle motion** — smooth view transitions and gentle state animations (no distracting hover effects), respecting `prefers-reduced-motion`.
- **Real alarm engine** — `chrome.alarms` + background service worker; reminders fire even when the popup is closed. Alarms are reconciled on install, startup and every worker wake-up, while active snoozes, Done state and pending one-offs survive Chrome recycling the background worker.
- **Notifications** via `chrome.notifications` with **Done** and **Snooze** buttons that keep working even after a worker restart. A laptop waking from sleep never replays a stale daily alarm; one-offs and snoozes you asked for still fire.
- **Actual alarm sounds** (Default Chime, Sunrise, Melody, Pop, Zen, Sparkle, Glass, Gentle, Digital, Cascade, Soft, Bell, Alarm) generated with WebAudio in an offscreen document — no asset files needed. Preview any sound right inside the reminder form.
- **Real voice reminders** — `chrome.tts` first, Web Speech API fallback; male/female/system voice, English/Nepali/Hindi, slow/normal/fast speed, volume, and a **Test Voice** button.
- **Snooze** (5/10/15/custom via default snooze setting), repeating reminders (once/daily/weekdays/custom days), enable/disable, **duplicate**, **search**, edit, delete.
- **Office hours** settings + **Create Workday Schedule** suggestions (always user-confirmed).
- **Toolbar clock** — the original logo artwork fills the toolbar icon edge-to-edge (drawn slightly oversized so the tile touches the icon edges), and the live local time is shown by Chrome as a crisp native badge in the corner. Updated every minute, 12/24h aware, and toggleable in Settings.
- **Settings**: 12/24h format, default snooze, theme (dark/light/system), toolbar clock, notification sound & volume, voice options, office schedule. Everything persists in `chrome.storage.local`.

## Install (from ZIP)

1. Download the latest **`work-reminder-v1.8.0.zip`** from this repository (open the ZIP file, then click **Download**) or from the [releases page](https://github.com/Nabinkdk7/Work-Reminder-Extension/releases).
2. Extract the ZIP anywhere (e.g. `Documents\WorkReminder`).
3. Open `chrome://extensions` in Chrome/Edge/Brave.
4. Enable **Developer mode** (top right).
5. Click **Load unpacked** and select the extracted folder (the one containing `manifest.json`).
6. Pin **Work Reminder** to the toolbar and open it — the default workday schedule is created automatically.

## Updating

The extension checks GitHub for new versions automatically every 12 hours, or on demand via
**Settings → Updates → Check for Updates**.

- If an update is available you get a **notification** (once per version) plus an update panel in Settings with a **Download Update** button and step-by-step install guide.
- No notification is shown when you are already up to date.
- After you install the new files and press **Reload** on `chrome://extensions`, the extension confirms with a *"Successfully updated"* notification.
- Browsers don't allow an unpacked extension to overwrite its own files, so updating is: download ZIP → extract over the extension folder → Reload. Your reminders and settings are preserved in `chrome.storage`.

## Test end-to-end

1. Open the popup → default schedule is seeded; every reminder can be edited/deleted.
2. Create a reminder for a minute or two from now (e.g. title `Return Cup`, message `Please return your cup to the kitchen.`).
3. Close the popup (Chrome can stay minimized or in the background — it needs to be running) — when the time hits, you get:
   - a browser notification,
   - the selected alarm sound,
   - speech of the message via voice settings.
4. Use the notification's **Done** / **Snooze** buttons, or the Schedule tab's check toggle.

## Architecture

| File | Role |
| ---- | ---- |
| `background.js` | Service worker: storage, alarm scheduling, firing, notifications, messages, update checker |
| `offscreen.js` | Offscreen doc: WebAudio sounds + Web Speech API voice (fallback) |
| `shared.js` | Shared time/schedule helpers, defaults, categories, voice pacing (popup, worker, offscreen) |
| `popup.html/css/js` | Dashboard UI: Home / Reminders / Schedule / Settings |
| `manifest.json` | MV3 manifest (storage, alarms, notifications, offscreen, idle, tts) |

## For maintainers — publishing a new version

1. Bump `"version"` in `manifest.json` (e.g. `1.8.0`).
2. Zip the extension files (with `manifest.json` at the ZIP root) as `work-reminder-v1.8.0.zip` — replacing the old ZIP so the repo always holds exactly one ZIP + `README.md`.
3. Update the version references in this repo's `README.md`, commit and push to `main`.
4. That's enough: installed copies detect the new ZIP filename via the GitHub API within 12 hours (or immediately via Check for Updates). A GitHub Release with notes is optional — when one exists, its notes and attached asset are used instead.
